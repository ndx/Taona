#include"pl_server.h"
#include"pl_statistics.h"
pl_server_t *
  responsetime(pl_server_t *srvlist, \
	    pl_algorithm_data_t *data)
{
    pl_server_t *srv = NULL, *scan;
    pl_ullong_t connections, alltime;
    pl_ullong_t no_trans;
    float min = ((pl_ullong_t)~0), aver_time;
    pl_int_t down, weight;
    for(scan = srvlist; scan!=NULL; \
		    scan = scan->next)
    {
	pl_get_stat_value(&(scan->info), \
	VDOWN, &down, sizeof(down));
	if( down ) continue;
	pl_get_stat_value(&(scan->info), \
	VWEIGHT, &weight, sizeof(weight));
	pl_get_stat_value(&(scan->info), \
	VSUM, &connections, sizeof(connections));
	pl_get_stat_value(&(scan->info), \
	VALLTIME, &alltime, sizeof(alltime));
	pl_get_stat_value(&(scan->info), \
	VNOTRANS, &no_trans, sizeof(no_trans));
	connections -= no_trans;
	if( !connections ) {
	    srv = scan;
	    min = aver_time;
	} else {
	    aver_time = ((float)alltime) / connections;
	    aver_time += ((1/(1+aver_time))*weight);
	    if( aver_time<min ) {
		srv = scan;
		min = aver_time;
	    }
	}
    }
    return srv;
}

