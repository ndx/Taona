
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_types.h"
#define __REAL_VARIABLE
#include"pl_global.h"

