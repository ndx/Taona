
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_server.h"
#include"pl_round_robin.h"
#include"pl_ip_hash.h"
#include"pl_statistics.h"
#include"pl_conf.h"
#include"pl_log.h"
#include"pl_global.h"
#include"pl_dynamic_lib.h"
#include<sys/time.h>
#include<string.h>
#include<time.h>

/*local function declarations*/
static void pl_get_server_conf(pl_var_t **pv, \
	pl_domain_t *pd, const pl_char_t *var, \
	pl_int_t type);

/*static variables*/
static pl_srvlist_t gsl;
static pl_algorithm algorithm;
static pl_char_t alnametbl[NRALG][NAME] = {
"roundrobin", "iphash"
};
static pl_algorithm alfunctbl[] = {
round_robin, ip_hash
};

void pl_init_server(void)
{
    algorithm = alfunctbl[0];
    memset(galname, 0, 256);
    strcpy(galname, "roundrobin");
    pl_char_t ip[IPLEN];
    pl_ushort_t port;
    pl_int_t weight, down;
    memset(&gsl, 0, sizeof(gsl));
    gsl.pool = pl_create_pool();
    if( gsl.pool==NULL ) {
	pl_log(ERROR, \
	"pl_init_server(): create pool error.");
    }
    pl_domain_t *pd = pl_get_current_domain();
    pd = pd->next;
    pl_var_t *pv;
    while( pd!=NULL ) {
	memset(ip, 0, IPLEN);
	pl_server_t *ps = pl_create_server_node();
	pl_mount_server_node(ps);
	pl_get_server_conf(&pv, pd, "ip", STR);
	strcpy(ip, pv->data.str);
	pl_get_server_conf(&pv, pd, "port", INT);
	port = (pl_ushort_t)(pv->data.value);
	pl_get_server_conf(&pv, pd, "weight", INT);
	weight = pv->data.value;
	pl_get_server_conf(&pv, pd, "down", STR);
	if( !strcasecmp(pv->data.str, "on") ) {
	    down = 1;
	} else if( !strcasecmp(pv->data.str, "off") ) {
	    down = 0;
	} else {
	    pl_log(ERROR, "pl_init_server(): type of \
item 'down' in domain '%s' is error.", pd->domain);
	}
	pl_set_server_node(ps, pd->domain, ip, \
			port, weight, down);
	pd = pd->next;
    }
}

static void pl_get_server_conf(pl_var_t **pv, \
	pl_domain_t *pd, const pl_char_t *var, \
	pl_int_t type)
{
    *pv = pl_get_conf(pd->domain, var, VAR);
    if( (*pv)==NULL ) {
	pl_log(ERROR, \
	"pl_init_server(): get conf variable error.");
    }
    if( (*pv)->type!=type ) {
	pl_log(ERROR, \
	"pl_init_server(): domain '%s' item '%s' type error.", \
	pd->domain, var);
    }
}

pl_server_t *pl_create_server_node(void)
{
    pl_server_t *ps = pl_alloc(gsl.pool, \
	sizeof(pl_server_t));
    if( ps==NULL ) {
	pl_log(ERROR, \
	"pl_create_server_node(): allocate pl_server_t error.");
    }
    return ps;
}

void pl_mount_server_node(pl_server_t *ps)
{
    if( ps==NULL ) {
	pl_log(ERROR, \
	"pl_mount_server_node(): Parameter is NULL.");
    }
    if( gsl.ps==NULL ) {
	gsl.ps = gsl.ps_tail = ps;
    } else {
	gsl.ps_tail->next = ps;
	ps->prev = gsl.ps_tail;
	gsl.ps_tail = ps;
    }
}

void pl_set_server_node(pl_server_t *ps, \
    const pl_char_t *srvname, const pl_char_t *ip, \
    pl_ushort_t port, pl_int_t weight, pl_int_t down)
{
    memset(ps->srvname, 0, NAME);
    strcpy(ps->srvname, srvname);
    memset(ps->ip, 0, IPLEN);
    strcpy(ps->ip, ip);
    ps->port = port;
    strcpy(ps->info.name, ps->srvname);
    pl_stat_ctl(&(ps->info), WEIGHT, VALUE, weight);
    pl_stat_ctl(&(ps->info), CWEIGHT, VALUE, weight);
    pl_stat_ctl(&(ps->info), DOWNSTATUS, VALUE, down);
}

void pl_del_server_node(pl_server_t *ps)
{
    if( ps==gsl.ps ) {
	if( ps==gsl.ps_tail ) {
	    gsl.ps = gsl.ps_tail = NULL;
	} else {
	    gsl.ps = ps->next;
	    gsl.ps->prev = NULL;
	}
    } else {
	if( ps==gsl.ps_tail ) {
	    gsl.ps_tail = ps->prev;
	    gsl.ps_tail->next = NULL;
	} else {
	    ps->prev->next = ps->next;
	    ps->next->prev = ps->prev;
	}
    }
    if( pl_free(ps)<0 ) {
	pl_log(ERROR, \
	"pl_del_server_node(): free pl_server_t error.");
    }
}

pl_server_t *pl_get_server_node(const pl_char_t *str, \
	pl_ushort_t port)
{
    if( str==NULL ) {
	return NULL;
    }
    pl_server_t *ps;
    for(ps = gsl.ps; ps!=NULL; ps = ps->next) {
	if( !port ) {
	    if( !strcmp(str, ps->srvname) ) {
		return ps;
	    }
	} else {
	    if( !strcmp(str, ps->ip) && \
		port==ps->port )
	    {
		return ps;
	    }
	}
    }
    return NULL;
}

pl_int_t pl_get_nr_server(void)
{
    pl_int_t cnt = 0;
    pl_server_t *ps;
    for(ps = gsl.ps; \
	ps!=NULL; \
	ps = ps->next)
    	cnt++;
    return cnt;
}

pl_server_t *pl_call_algorithm(void *data)
{
	return (algorithm(gsl.ps, data));
}

pl_int_t pl_set_algorithm(const pl_char_t *alname)
{
    pl_int_t i;
    for(i = 0; i<NRALG; i++) {
	if( !strcasecmp(alname, alnametbl[i]) ) {
	    break;
	}
    }
    if( i<NRALG ) {
	memset(galname, 0, 256);
	strcpy(galname, alname);
	algorithm = alfunctbl[i];
	return 0;
    }
    if( pl_chech_dynamic_lib(alname)<0 )
	return -1;
    algorithm = pl_return_alptr(alname);
    if( algorithm==NULL ) {
	memset(galname, 0, 256);
	strcpy(galname, "roundrobin");
	algorithm = alfunctbl[0];
	pl_log(DEBUG, "pl_set_algorithm(): \
Dynamic library %s lost. Swtich to roundrobin");
    } else {
	memset(galname, 0, 256);
	strcpy(galname, alname);
    }
    return 0;
}

void pl_set_server_idle(void)
{
    pl_time_t tm = time(NULL);
    pl_server_t *ps;
    for(ps = gsl.ps; ps!=NULL; ps = ps->next) {
	pl_stat_ctl(&(ps->info), IDLE, VALUE, tm);
	    pl_init_stat_min_value(&(ps->info));
    }
}

pl_server_t *pl_get_server_list(void)
{
    return gsl.ps;
}

/*void pl_print_server(void)
{
	pl_server_t *ps;
	for(ps = gsl.ps; ps!=NULL; ps = ps->next) {
		printf("server:%s\nip:%s\nport:%d\nweight:%d\ncurrent_weight:%d\ndown:%d\n", \
		ps->srvname, ps->ip, ps->port, ps->info.weight, ps->info.current_weight, ps->info.down);
	}
}*/

