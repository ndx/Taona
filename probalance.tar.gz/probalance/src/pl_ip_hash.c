
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_ip_hash.h"
#include"pl_round_robin.h"
#include"pl_log.h"
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>
#include<stdlib.h>

/*local function declarations*/

/*static variables*/
static pl_hash_table_t hashtbl[TBLLEN];

pl_server_t *ip_hash(pl_server_t *srvlist, \
	pl_algorithm_data_t *data)
{
    pl_char_t pre[PREFIX], *p, *q;
    pl_int_t key;
    memset(pre, 0, PREFIX);
    p = inet_ntoa(data->addr.sin_addr);
    for(q = pre; *p!='.'; p++, q++) {
	*q = *p;
    }
    key = atoi(pre);
    if( key>255 || key<0 ) {
	pl_log(ERROR, \
	"ip_hash(): no such kind of prefix: %d.", key);
    }
    if( hashtbl[key].key==key ) {
	return hashtbl[key].srv;
    }
    pl_server_t *srv = round_robin(srvlist, data);
    if( srv==NULL ) {
	return NULL;
    }
    hashtbl[key].srv = srv;
    hashtbl[key].key = key;
    return srv;
}

void pl_clean_hash_table(void)
{
    memset(hashtbl, -1, \
	sizeof(pl_hash_table_t)*TBLLEN);
}

