
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_lock.h"
#include"pl_log.h"
#include"pl_fork.h"
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<errno.h>
/*local function declarations*/
static pl_int_t pl_lock(pl_int_t type);
/*static variales*/
static pl_int_t lockfd;

void pl_create_lock(void)
{
    if( access("tmp", F_OK)<0 ) {
	if( mkdir("tmp", S_IRUSR | S_IWUSR | S_IXUSR | \
		S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH)<0 )
	{
	    pl_log(ERROR, \
		"pl_create_lock(): mkdir error. %s.", \
		strerror(errno));
	}
    }
    if( access("tmp/lockfile", F_OK)<0 ) {
	lockfd = open("tmp/lockfile", \
		O_CREAT|O_RDWR, S_IRUSR | S_IWUSR | \
		S_IXUSR | S_IRGRP | S_IROTH);
    } else {
	lockfd = open("tmp/lockfile", O_RDWR);
    }
    if( lockfd<0 ) {
	pl_log(ERROR, \
	"pl_create_lock(): open tmp/lockfile error. %s.", \
	strerror(errno));
    }
}

static pl_int_t pl_lock(pl_int_t type)
{
    struct flock lock;
    lock.l_type = type;
    lock.l_start = 0;
    lock.l_whence = SEEK_SET;
    lock.l_len = 0;
    return (fcntl(lockfd, F_SETLK, &lock));
}

pl_int_t pl_add_lock(void)
{
    if( pl_lock(F_WRLCK)<0 ) {
	if( errno==EAGAIN ) {
	    return -1;
	} else {
	    pl_log(ERROR, \
	    "pl_add_lock(): lock error. %s.", \
	    strerror(errno));
	}
    }
    return 0;
}

void pl_unlock(void)
{
    if( pl_lock(F_UNLCK)<0 ) {
	pl_log(ERROR, \
	"pl_unlock(): unlock error. %s.", \
	strerror(errno));
    }
}


void pl_remove_lock(void)
{
    close(lockfd);
}

