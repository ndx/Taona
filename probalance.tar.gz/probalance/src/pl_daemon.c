
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_daemon.h"
#include"pl_types.h"
#include"pl_log.h"
#include"pl_conf.h"
#include<fcntl.h>
#include<errno.h>

void pl_init_daemon(void)
{
    pl_domain_t *pd;
    pd = pl_get_current_domain();
    pl_var_t *pv;
    pv = pl_get_conf(pd->domain, "daemon_status", VAR);
    if( pv!=NULL ) {
	if( pv->type!=STR ) {
	    fprintf(stderr, "pl_init_daemon(): type of \
item 'daemon_status' in domain '%s' is error.\n", pd->domain);
	    exit(1);
	}
	if( !strcasecmp(pv->data.str, "off") ) {
	    return ;
	} else if( !strcasecmp(pv->data.str, "on") ) {
	    /*do nothing*/
	} else {
	    fprintf(stderr, "pl_init_daemon(): value of \
item 'daemon_status' in domain '%s' is error.\n", pd->domain);
	    exit(1);
	}
    }
    pl_int_t fd0, fd1, fd2;
    pl_pid_t pid;
    if( (pid = fork())<0 ) {
	fprintf(stderr, "pl_init_daemon(): fork error. %s.\n", \
	strerror(errno)); exit(1);
    } else if( pid>0 ) {
	exit(0);
    }
    if( (pid = fork())<0 ) {
	fprintf(stderr, "pl_init_daemon(): second fork error. %s.\n", \
	strerror(errno)); exit(1);
    } else if( pid>0 ) {
	exit(0);
    }
    if( setsid()<0 ) {
	fprintf(stderr, "pl_init_daemon(): setsid error. %s.\n", \
	strerror(errno)); exit(1);
    }
    close(0); close(1); close(2);
    fd0 = open("/dev/null", O_RDWR);
    fd1 = dup(0); fd2 = dup(0);
    if( fd0!=0 || fd1!=1 || fd2!=2 ) {
	fprintf(stderr, "pl_init_daemon(): dup fd is not 0 1 2.\n");
	exit(1);
    }
}

