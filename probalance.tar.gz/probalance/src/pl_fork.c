
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_fork.h"
#include"pl_global.h"
#include"pl_log.h"
#include"pl_conf.h"
#include"pl_alloc.h"
#include"pl_lock.h"
#include<sys/types.h>
#include<unistd.h>
#include<string.h>
#include<signal.h>
#include<sys/socket.h>
#define __USE_GNU
#include<sched.h>
/*local function declarations*/
static void pl_init_signal(void);
static void 
pl_INT_QUIT_sighandler(pl_int_t signo);

/*static variables*/
static pl_proclist_t gpl;
static pl_int_t cpu_affinity = 0;
static pl_int_t cur_cpu = 0;

void pl_fork(pl_char_t *argv[])
{
    memset(&gpl, 0, sizeof(gpl));
    gpl.type = MASTER;
    pl_domain_t *pd = pl_get_current_domain();
    pl_var_t *pv;
    pv = pl_get_conf(pd->domain, "work_process", VAR);
    if( pv==NULL ) {
	pl_log(ERROR, \
	"pl_fork(): item 'work_process' in domain '%s' \
is not existed.", pd->domain);
    }
    if( pv->type==STR ) {
	if( !strcasecmp(pv->data.str, "auto") ) {
	    gpl.autoadjust = 1;
	    gpl.nr_proc = 1;
	    pv = pl_get_conf(pd->domain, "max_nr_process", VAR);
	    if( pv==NULL ) {
		pl_log(ERROR, \
		"pl_fork(): item 'max_nr_process' in domain %s \
is not existed.", pd->domain);
	    }
	    if( pv->type!=INT || pv->data.value<1) {
		pl_log(ERROR, \
		"pl_fork(): value of item 'max_nr_process' \
in domain %s is error.", pd->domain);
	    }
	    gpl.max_nr_proc = pv->data.value;
	} else {
	    goto err;
	}
    } else if( pv->type==INT ) {
	gpl.nr_proc = pv->data.value;
	if( gpl.nr_proc<1 ) {
err:	    pl_log(ERROR, \
	    "pl_fork(): value of item 'work_process' should \
greater than zero.");
	}	
    } else {
	pl_log(ERROR, \
	"pl_fork(): type of item 'work_process' in domain '%s' \
is error.", pd->domain);
    }
	
    pv = pl_get_conf(pd->domain, "cpu_affinity", VAR);
    if( pv==NULL ) {
	pl_log(ERROR, \
	"pl_fork_child(): item 'cpu_affinity' in domain '%s' \
is not existed.", pd->domain);
    }
    if( pv->type!=STR ) {
	pl_log(ERROR, \
	"pl_fork_child(): type of item 'cpu_affinity' in \
domain '%s' is error.", pd->domain);
    }
    if( !strcasecmp(pv->data.str, "on") ) {
	cpu_affinity = 1;
    } else if( !strcasecmp(pv->data.str, "off") ) {
	cpu_affinity = 0;
    } else {
	pl_log(ERROR, \
	"pl_fork_child(): value of item 'cpu_affinity' in \
domain '%s' is error.", pd->domain);
    }

    gpl.pool = pl_create_pool();
    if( gpl.pool==NULL ) {
	pl_log(ERROR, "pl_fork(): create pool error.");
    }
	
    sprintf(argv[0], "probalance master process");
	
    gpl.nr_cpu = sysconf(_SC_NPROCESSORS_CONF);
	
    pl_int_t i;
    for(i = 0; i<gpl.nr_proc; i++) {
	if( pl_fork_child(argv)==WORKER ) {
	    return;
	}
    }
    pl_init_signal();
}

pl_int_t pl_fork_child(pl_char_t *argv[])
{
    pl_pid_t pid;
    pl_int_t fd[2];
    if( socketpair(AF_UNIX, SOCK_STREAM, 0, fd)<0 ) {
	pl_log(ERROR, "pl_fork_child(): socketpair error. %s.", \
	strerror(errno));
    }
    if( (pid = fork())<0 ) {
	pl_log(ERROR, "pl_fork_child(): fork error, %s.", \
	strerror(errno));
    } else if( pid==0 ) {
	nr_fds = 0;
	pl_set_nr_proc(1);
	gpl.type = WORKER;
	pl_proc_t *pp = gpl.pp, *rm;
	while( pp!=NULL ) {
	    rm = pp;
	    pp = pp->next;
	    close(rm->ps->sockfd);
	    pl_del_from_queue(rm->ps->pb);
	    pl_del_proc(rm);
	}
	pl_bind_t *pb = pl_get_bind(), *rmb;
	pl_int_t i;
	while( pb!=NULL ) {
	    rmb = pb;
	    pb = pb->next;
	    for(i = 0; i<2; i++) {
		if( rmb->s[i].sockfd!=0 && \
		    rmb->s[i].type!=LISTEN )
		{
		    close(rmb->s[i].sockfd);
		    rmb->s[i].status = DEAD;
		    rmb->status |= (rmb->s[i].status)<<i*16;
		    if( rmb->s[i].type==CONSOLE || \
			rmb->s[i].type==(CONSOLE|ACCEPT) )
		    {
			rmb->s[i?0:1].status = DEAD;
			rmb->status |= DEAD<<((i?0:1)*16);
		    }
		}
	    }
	    if( rmb->status==ALLDEAD ) {
		pl_del_from_queue(rmb);
	    }
	}
	close(fd[0]);
	pl_setnonblock(fd[1]);
	pl_pid_t childpid = getpid();
	pp = pl_create_proc();
	pl_mount_proc(pp);
	pl_set_proc(pp, cur_cpu,fd[1], childpid);
	sprintf(argv[0], "probalance worker process");
	/*cpu affinity------------------------------*/
	if( cpu_affinity ) {
	    cpu_set_t cpu_set;
	    CPU_ZERO(&cpu_set);
	    CPU_SET(cur_cpu, &cpu_set);
	    if( sched_setaffinity(0, sizeof(cpu_set), \
		&(cpu_set))<0 )
	    {
		pl_log(ERROR, "pl_fork_child(): \
setaffinity error. %s.", strerror(errno));
	    }
	}
	/*end cpu affinity--------------------------*/
	if( ++cur_cpu==gpl.nr_cpu ) {
	    cur_cpu = 0;
	}
	if( signal(SIGINT, SIG_DFL)==SIG_ERR ) {
	    pl_log(ERROR, \
		"child process set signal SIGINT default error.");
	}
	if( signal(SIGQUIT, SIG_DFL)==SIG_ERR ) {
	    pl_log(ERROR, \
		"child process set signal SIGQUIT default error.");
	}
	if( signal(SIGCHLD, SIG_DFL)==SIG_ERR ) {
	    pl_log(ERROR, \
		"child process set signal SIGCHLD default error.");
	}
	if( signal(SIGPIPE, SIG_IGN)==SIG_ERR ) {
	    pl_log(ERROR, \
		"child process set signal SIGPIPE default error.");
	}
	return WORKER;
    }
    close(fd[1]);
    pl_setnonblock(fd[0]);
    pl_proc_t *pp;
    pp = pl_create_proc();
    pl_mount_proc(pp);
    pl_set_proc(pp, cur_cpu, fd[0], pid);
    if( ++cur_cpu==gpl.nr_cpu ) {
	cur_cpu = 0;
    }
    return fd[0];	
}

pl_proc_t *pl_create_proc(void)
{
    pl_proc_t *pp;
    pp = pl_alloc(gpl.pool,sizeof(pl_proc_t));
    if( pp==NULL ) {
	pl_log(ERROR, \
	"pl_create_proc(): allocate pl_proc_t error.");
    }
    return pp;
}

void pl_mount_proc(pl_proc_t *pp)
{
    if( pp==NULL ) {
	pl_log(ERROR, \
	"pl_mount_proc(): parameter 'pp' is NULL.");
    }
    if( gpl.pp==NULL ) {
	gpl.pp = gpl.pp_tail = pp;
    } else {
	gpl.pp_tail->next = pp;
	pp->prev = gpl.pp_tail;
	gpl.pp_tail = pp;
    }
}

void pl_set_proc(pl_proc_t *pp, pl_int_t no_cpu, \
		pl_int_t pairfd, pl_pid_t pid)
{
    pl_bind_t *pb;
    pb = pl_create_bind();
    pl_add_in_queue(pb);
    pl_socket_t *ps = &(pb->s[PAIR>>MOV]);
    pl_set_socket(ps, PAIR, NULL, pb, pairfd);
    pp->ps = ps;
    pp->no_cpu = no_cpu;
    pp->pid = pid;
}

void pl_del_proc(pl_proc_t *pp)
{
    if( pp==gpl.pp ) {
	if( pp==gpl.pp_tail ) {
	    gpl.pp = gpl.pp_tail = NULL;
	} else {
	    gpl.pp = pp->next;
	    gpl.pp->prev = NULL;
	}
    } else {
	if( pp==gpl.pp_tail ) {
	    gpl.pp_tail = pp->prev;
	    gpl.pp_tail->next = NULL;
	} else {
	    pp->prev->next = pp->next;
	    pp->next->prev = pp->prev;
	}
    }
    if( pl_free(pp)<0 ) {
	pl_log(ERROR, \
	"pl_del_proc(): free pl_proc_t error.");
    }
}

pl_int_t pl_get_proc_type(void)
{
	return gpl.type;
}

pl_int_t pl_get_nr_proc(void)
{
	return gpl.nr_proc;
}

void pl_set_nr_proc(pl_int_t num)
{
    if( num>=0 ) gpl.nr_proc = num;
}

static void pl_init_signal(void)
{
    if( signal(SIGCHLD, SIG_IGN)==SIG_ERR ) {
	pl_log(ERROR, \
	"pl_init_signal(): signal SIGCHLD error.");
    }
    if( signal(SIGINT, pl_INT_QUIT_sighandler)==SIG_ERR ) {
	fprintf(stderr, \
	"pl_init_signal(): set SIGINT handler error.\n");
	exit(1);
    }
    if( signal(SIGQUIT, pl_INT_QUIT_sighandler)==SIG_ERR ) {
	fprintf(stderr, \
	"pl_init_signal(): set SIGQUIT handler error.\n");
	exit(1);
    }
}

static void 
pl_INT_QUIT_sighandler(pl_int_t signo)
{
	if( pl_get_proc_type()==WORKER ) {
		exit(1);
	}
	pl_proc_t *pp;
	for(pp = gpl.pp; pp!=NULL; pp = pp->next) {
		kill(pp->pid, SIGKILL);
	}
	pl_remove_lock();
	exit(127);
}

void pl_del_proc_node_socket(pl_socket_t *ps)
{
	pl_proc_t *pp;
	for(pp = gpl.pp; pp!=NULL; pp = pp->next) {
		if( ps==pp->ps ) {
			break;
		}
	}
	pl_del_proc(pp);
}

pl_socket_t *pl_get_pair_sockfd(pl_int_t fd)
{
    pl_proc_t *pp;
    for(pp = gpl.pp; pp!=NULL; pp = pp->next) {
	if( fd==pp->ps->sockfd ) {
	    return pp->ps;
	}
    }
    return NULL;
}

pl_proc_t *pl_get_proc_list(void)
{
	return gpl.pp;
}

pl_int_t pl_get_autoadjust(void)
{
	return gpl.autoadjust;
}

pl_int_t pl_get_maxnrproc(void)
{
	return gpl.max_nr_proc;
}

/*void pl_print_fork(void)
{
	pl_proc_t *pp;
	for(pp = gpl.pp; pp!=NULL; pp = pp->next) {
		if( gpl.type==MASTER ) {
			printf("MASTER\n");
		} else {
			printf("WORKER\n");
		}
		printf("\tcurrent pid:%d\n", getpid());
		printf("\tno_cpu:%d\n", pp->no_cpu);
		printf("\trecord pid:%d\n", pp->pid);
		printf("\tpairfd:%d\n", pp->ps->sockfd);
		printf("\n");
	}
}*/

