
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_syslimit.h"
#include"pl_conf.h"
#include"pl_log.h"
#include<sys/time.h>
#include<sys/resource.h>
#include<unistd.h>
#include<sys/types.h>
/*local function declarations*/
static void pl_cancel_core(void);
static void pl_externed_fd(void);
/*static variables*/
static pl_int_t work_connections;

void pl_init_sysresource(void)
{
    pl_cancel_core();
    pl_externed_fd();
}

static void pl_cancel_core(void)
{
    struct rlimit rl;
    rl.rlim_cur = 0;
    rl.rlim_max = 0;
    if( setrlimit(RLIMIT_CORE, &rl)<0 ) {
	pl_log(ERROR, \
	"pl_cancel_core(): setrlimit error. %s.", \
	strerror(errno));
    }
}

static void pl_externed_fd(void)
{
    pl_domain_t *pd = pl_get_current_domain();
    pl_var_t *pv = pl_get_conf(pd->domain, \
	"work_connections", VAR);
    if( pv==NULL ) {
	pl_log(ERROR, "pl_externed_fd(): item \
'work_connections' in domain '%s' is not existed.", \
	pd->domain);
    }
    if( pv->type!=INT ) {
	pl_log(ERROR, "pl_externed_fd(): type of item \
'work_connections' in domain '%s' is error.", \
	pd->domain);
    }
    work_connections = pv->data.value;
    if( work_connections>65535 || \
	work_connections<1024 )
    {
	pl_log(ERROR, "pl_externed_fd(): value of item \
'work_connections' should between 1024 and 65535.");
    }
    if( getuid()!=0 ) {
	work_connections = 1024;
	return ;
    }
    struct rlimit rl;
    rl.rlim_cur = pv->data.value;
    rl.rlim_max = pv->data.value;
    if( setrlimit(RLIMIT_NOFILE, &rl)<0 ) {
	pl_log(ERROR, \
	"pl_externed_fd(): setrlimit error. %s.", \
	strerror(errno));
    }
}

pl_int_t pl_get_work_connections(void)
{
    return work_connections;
}

