
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_conf.h"
#include"pl_io.h"
#define __PL_RULE
#include"pl_access.h"
#include"pl_log.h"
#include"pl_statistics.h"
#include"pl_console.h"
#include"pl_event.h"
#include"pl_global.h"
#include"pl_fork.h"
#include"pl_socket.h"
#include"pl_ip_hash.h"
#include"pl_dynamic_lib.h"
#include<unistd.h>
#include<string.h>
#include<errno.h>
#include<time.h>
#include<signal.h>
#include<sys/time.h>

/*local function declarations*/
static void pl_deliver_msg(pl_console_package_t *pcp);
static void 
pl_process(pl_socket_t *ps, \
		pl_console_package_t *pcp);
static void
pl_process_client(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_server(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_set_lba(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_access(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_set_acl(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_set_server(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_del_acl(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_add_acl(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_del_server(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_add_server(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_turn_acl(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_turn_server(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_clear(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_quit(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_add_proc(pl_socket_t *ps, \
	pl_console_package_t *pcp);
static void
pl_process_turn_restart(pl_socket_t *ps, \
	pl_console_package_t *pcp);

/*static variables*/
static pl_int_t cmd = 0;
static pl_socket_t *psconsole = NULL;
static pl_cmd_process
process_table[] = {
NULL, NULL, pl_process_quit, pl_process_clear, \
pl_process_turn_server, pl_process_turn_acl, \
pl_process_add_server, pl_process_del_server, \
pl_process_add_acl, pl_process_del_acl, \
pl_process_set_server, pl_process_set_acl, \
pl_process_access, pl_process_set_lba, \
pl_process_server, pl_process_client, \
pl_process_add_proc, pl_process_turn_restart
};

void pl_request_recv(pl_socket_t *ps, \
	pl_int_t flg)
{
    if( ps->status==DEAD )
	return;
    pl_socket_t *other;
    other = pl_get_other_socket(ps);
    pl_char_t buf[BUFFER];
    pl_int_t n;
    pl_chain_t *pc;
    memset(buf, 0, BUFFER);
    while( (n = read(ps->sockfd, buf, BUFFER))>0 ) {
	ps->out += n;
	if( other->status!=DEAD ) {
	    pc = pl_create_chain_node();
	    pl_add_chain_node(buf, n, other, pc);
	}
	memset(buf, 0, BUFFER);
    }
    if( n<0 && errno==EAGAIN ) {
	if( other->status==INIT ) return;
	if( other->status!=DEAD ) {
	    pl_ctl_event(other, EPOLLOUT|EPOLLONESHOT|EPOLLET, MOD);
	    other->status |= SENDING;
	} else {
	    pl_ctl_event(ps, EPOLLOUT|EPOLLONESHOT|EPOLLET, MOD);
	    ps->status |= SENDING;
	}
    } else {
	if( n<0 ) {
	    pl_log(DEBUG, "pl_request_read(): read error. %s.", \
		strerror(errno));
	    /*-------statistics start---------------*/
	    if( ps->type==CONNECT ) {
		pl_stat_ctl(&(ps->srv->info), FAILED, INC, 0);
	    } else if( ps->type==(ACCEPT|LISTEN) ) {
		pl_stat_ctl(&clientinfo, FAILED, INC, 0);
	    }
	    /*-------statistics end-----------------*/
	}
	if( other->status!=DEAD ) {
	    pl_ctl_event(other, EPOLLOUT|EPOLLONESHOT|EPOLLET, MOD);
	    other->status |= SENDING;
	}
	pl_close_socket(ps, flg);
    }
}

void pl_request_send(pl_socket_t *ps, \
	pl_int_t flg)
{
    if( ps->status==DEAD )
	return;
    pl_char_t *p;
    pl_int_t n, size;
    pl_chain_t *pc;
    pl_socket_t *other;
    other = pl_get_other_socket(ps);
    if( other->status==DEAD && ps->pc==NULL ) {
	pl_close_socket(ps, flg|POSITIVE);
	return ;
    }
lp: pc = ps->pc;
    p = pc->buf + pc->w_size;
    size = pc->size - pc->w_size;
    while( (n = write(ps->sockfd, p, size))>0 ) {
	pc->w_size += n;
	ps->in += n;
	if( n==size ) {
	    pl_del_chain_node(ps, pc);
	    if( ps->pc==NULL ) {
		if( other->status==DEAD ) {
		    pl_close_socket(ps, flg|POSITIVE);
		} else {
		    ps->status &= ~SENDING;
		    if( !(other->status&SENDING) ) {
			pl_ctl_event(ps, \
			EPOLLIN|EPOLLONESHOT|EPOLLET, MOD);
			pl_ctl_event(other, \
			EPOLLIN|EPOLLONESHOT|EPOLLET, MOD);
		    }
		}
		return ;
	    } else {
		goto lp;
	    }
	} else {
	    goto lp;
	}
    }
    if( n<0 && errno==EAGAIN ) {
	pl_ctl_event(ps, EPOLLOUT|EPOLLONESHOT|EPOLLET, MOD);
    } else {
	if( n<0 ) {
	    pl_log(DEBUG, "pl_request_send(): write error. %s.", \
		strerror(errno));
	    /*-------statistics start---------------*/
	    if( ps->type==CONNECT ) {
		pl_stat_ctl(&(ps->srv->info), FAILED, INC, 0);
	    } else if( ps->type==(ACCEPT|LISTEN) ) {
		pl_stat_ctl(&clientinfo, FAILED, INC, 0);
	    }
	    /*-------statistics end-----------------*/
	}
	if( other->status!=DEAD ) {
	    pl_ctl_event(other, EPOLLOUT|EPOLLONESHOT|EPOLLET, MOD);
	    other->status |= SENDING;
	}
	pl_close_socket(ps, flg);
    }
}

void pl_close_socket(pl_socket_t *ps, pl_int_t flg)
{
    /*----------statistics start-----------*/
    pl_statinfo_t *pst;
    pl_int_t type = ps->type;
    if( type==CONNECT || type==(ACCEPT|LISTEN) ) {
	if( type==CONNECT ) {
	    pst = &(ps->srv->info);
	} else {
	    pst = &clientinfo;
	}
	pl_stat_ctl(pst, OUT, VALUE, ps->out);
	pl_stat_ctl(pst, IN, VALUE, ps->in);
	if( !ps->in && !ps->out ) {
	    pl_stat_ctl(pst, NOTRANS, INC, 0);
	}
	if( !pst->current_connections )
	    pl_stat_ctl(pst, IDLE, VALUE, time(NULL));
	pl_stat_ctl(pst, SUM, INC, 0);
	pl_stat_ctl(pst, CURRENT, DEC, 0);
	struct timeval end;
	if( gettimeofday(&end, NULL)<0 ) {
	    pl_log(EMERGE, \
	    "pl_close_socket(): gettimeofday error. %s.", \
	    strerror(errno));
	}
	pl_ullong_t val;
	val = (end.tv_sec - ps->start.tv_sec) * 1000000 + \
	    (end.tv_usec - ps->start.tv_usec);
	pl_stat_ctl(pst, TIME, VALUE, val);
	pl_ullong_t current;
	pl_get_stat_value(pst, VCURRENT, &current, sizeof(current));
	if( !current ) {
	    pl_stat_ctl(pst, IDLE, VALUE, time(NULL));
	}
    }
    /*----------statistics end-------------*/
    if( ps->type==CONNECT && flg==(CACHE|POSITIVE) ) {
	pl_event_cache_t *put, *get;
	pl_uint_t remain = alarm(0);
	if( !remain )
	    remain = 1;
	put = pl_return_cache_pointer(PUT);
	if( put!=NULL ) {
	    memcpy(&(put->s), ps, sizeof(pl_socket_t));
	    put->start = time(NULL);
	    pl_next_available_cache(PUT);
	    get = pl_return_cache_pointer(GET);
	    if( get==NULL ) {
		pl_assign_cache_pointer(GET, put);
	    }
	    pl_ctl_event(ps, EPOLLIN, DEL);
	    alarm(remain);
	    goto goon;
	}
	alarm(remain);
    }
    close(ps->sockfd);
    nr_fds--;
goon:if( ps->type==CONNECT ) {
	pl_del_sock_list(ps->srv, ps);
    }
    ps->status = DEAD;
    ps->pb->status |= DEAD<<(ps-ps->pb->s)*16;
    if( ps->type==PAIR || ps->type==(CONSOLE|ACCEPT) ) {
	pl_socket_t *other = pl_get_other_socket(ps);
	other->status = DEAD;
	ps->pb->status |= DEAD<<((ps-ps->pb->s)?0:1)*16;
    }
    if( ps->pb->status==ALLDEAD ) {
	pl_del_from_queue(ps->pb);
    }
}

void pl_console_recv(pl_socket_t *ps, const pl_char_t *func)
{
    pl_int_t n;
    static pl_chain_t *pc;
    static pl_int_t recv_done = 0;
    pl_char_t *p;
    if( !recv_done ) {
	pc = calloc(1, sizeof(pl_chain_t));
	if( pc==NULL ) {
	    pl_log(EMERGE, "%s: calloc pl_chain_t error.", func);
	}
	pc->buf = calloc(1, BUFFER);
	if( pc->buf==NULL ) {
	    pl_log(EMERGE, "%s: calloc block BUFFER error.", func);
	}
    }
    p = pc->buf + pc->w_size;
    n = read(ps->sockfd, p, BUFFER);
    if( n==0 ) {
	if( !strcasecmp(func, "pl_worker_ipc_recv()") ) {
	    pl_log(ERROR, "pl_worker_ipc_recv(): Master \
process is killed. Worker process %d quit.", getpid());
	}
out:	pl_close_socket(ps, 0);
	console_existed = 0;
	psconsole = NULL;
	return ;
    } else if( n<0 ) {
	pl_log(DEBUG, "%s: read error. %s.", func, strerror(errno));
	goto out;
    } else {
	pc->w_size += n;
	if( pc->w_size!=sizeof(pl_console_package_t) ) {
	    recv_done = 1;
	    return ;
	}
    }
    psconsole = ps;
    pl_process(ps, (pl_console_package_t *)(pc->buf));
    free(pc->buf);
    free(pc);
    recv_done = 0;
    pc = NULL;
}

void pl_console_send(pl_socket_t *ps, \
		    const pl_char_t *func)
{
    pl_char_t *p;
    pl_int_t n, size;
    size = ps->pc->size - ps->pc->w_size;
    p = ps->pc->buf + ps->pc->w_size;
    n = write(ps->sockfd, p, size);
    if( n<0 ) {
	pl_log(EMERGE, \
	"%s: write error. %s.", \
	func, strerror(errno));
	pl_close_socket(ps, 0);
	return ;
    } else {
	ps->pc->w_size += n;
	if( n==size ) {
	    pl_del_chain_node(ps, ps->pc);
	}
    }
    if( ps->pc==NULL ) {
	pl_ctl_event(ps, EPOLLIN, MOD);
    }
}

static void 
pl_process(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    cmd = pcp->cmd;
    process_table[pcp->cmd](ps, pcp);
}

static void
pl_process_quit(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    raise(SIGINT);
}

static void
pl_process_clear(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc;
    proc = pl_get_proc_type();
    if( proc==MASTER ) {
	pl_deliver_msg(pcp);
	pl_int_t rv = 0;
	pl_send_package_num(ps, rv);
	return ;
    }
    /*WORKER*/
    pl_int_t weight, cweight, down;
    pl_time_t idle;
    pl_get_stat_value(&clientinfo, \
	VWEIGHT, &weight, sizeof(weight));
    pl_get_stat_value(&clientinfo, \
	VCWEIGHT, &cweight, sizeof(cweight));
    pl_get_stat_value(&clientinfo, \
	VDOWN, &down, sizeof(down));
    pl_get_stat_value(&clientinfo, \
	VIDLE, &idle, sizeof(idle));
    memset(&clientinfo, 0, sizeof(pl_statinfo_t));
    pl_stat_ctl(&clientinfo, WEIGHT, VALUE, weight);
    pl_stat_ctl(&clientinfo, CWEIGHT, VALUE, cweight);
    pl_stat_ctl(&clientinfo, DOWNSTATUS, VALUE, down);
    pl_stat_ctl(&clientinfo, IDLE, VALUE, idle);
    pl_server_t *srv = pl_get_server_list();
    while( srv!=NULL ) {
	pl_get_stat_value(&(srv->info), \
	    VWEIGHT, &weight, sizeof(weight));
	pl_get_stat_value(&(srv->info), \
	    VCWEIGHT, &cweight, sizeof(cweight));
	pl_get_stat_value(&(srv->info), \
	    VDOWN, &down, sizeof(down));
	pl_get_stat_value(&(srv->info), \
	    VIDLE, &idle, sizeof(idle));
	memset(&(srv->info), 0, sizeof(pl_statinfo_t));
	pl_stat_ctl(&(srv->info), WEIGHT, VALUE, weight);
	pl_stat_ctl(&(srv->info), CWEIGHT, VALUE, cweight);
	pl_stat_ctl(&(srv->info), DOWNSTATUS, VALUE, down);
	pl_stat_ctl(&(srv->info), IDLE, VALUE, idle);
	strcpy(srv->info.name, srv->srvname);
	srv = srv->next;
    }
}

static void
pl_process_turn_server(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_server_t *srv = pl_get_server_list();
    pl_int_t rv = 0, all = 0, down = 0;
    if( !strcasecmp(pcp->param, "all") ) {
	all = 1;
    }
    if( pcp->status==DOWN ) {
	down = 1;
    }
    while( srv!=NULL ) {
	if( all ) {
	    pl_stat_ctl(&(srv->info), DOWNSTATUS, VALUE, down);
	    if( down )
		pl_clean_cache_by_server(srv);
	} else if( !strcasecmp(pcp->param, srv->srvname) ) {
	    pl_stat_ctl(&(srv->info), DOWNSTATUS, VALUE, down);
	    if( down )
		pl_clean_cache_by_server(srv);
	    break;
	}
	srv = srv->next;
    }
    if( proc==MASTER ) {
	if( !all && srv==NULL ) {
	    rv = -1;
	}
	pl_send_package_num(ps, rv);
	if( rv==0 ) {
	    pl_deliver_msg(pcp);
	}
    }
}

/*pl_process_turn_acl():
WARNING: if user want to use command 'turnacl' to change the
ACL's status, please make sure that the ACL's configuration
file wouldn't be changed before confirming ACL's status was
really changed. You can use command 'access' to print all 
ACL rules. If the status is off, nothing will be printed. Or 
the new rules will be printed.*/
static void
pl_process_turn_acl(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_int_t rv = 0;
    if( pcp->status==OFF ) {
	if(  proc==MASTER ) {
	    pl_send_package_num(ps, rv);
	    pl_deliver_msg(pcp);
	}
	pl_change_acl_status(0);
	pl_clean_all_acl();
	return ;
    }
    pl_domain_t *pd = pl_get_current_domain();
    pl_var_t *pv;
    pv = pl_get_conf(pd->domain, "acl_path", VAR);
    if( pv==NULL ) {
	rv = -1;
    } else if( pv->type!=STR ) {
	rv = -1;
    } else {
	if( proc==MASTER ) {
	    pl_deliver_msg(pcp);
	}
    }
    if( proc==MASTER ) {
	pl_send_package_num(ps, rv);
    }
    if( rv<0 ) return ;
    pl_clean_all_acl();
    pl_change_acl_status(1);
    pl_get_acl_conf(pv->data.str);
}

static void
pl_process_add_server(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_int_t rv = 0;
    pl_server_t *srv;
    srv = pl_get_server_node(pcp->param, 0);
    if( srv!=NULL ) {
	rv = -1;
    } else {
	srv = pl_get_server_node(pcp->ip, pcp->port);
	if( srv!=NULL ) {
	    rv = -1;
	}
    }
    if( proc==MASTER ) {
	pl_send_package_num(ps, rv);
	if( rv<0 ) {
	    return ;
	} else {
	    pl_deliver_msg(pcp);
	}
    }
    pl_int_t down = 0;
    if( pcp->status==DOWN ) {
	down = 1;
    }
    srv = pl_create_server_node();
    pl_mount_server_node(srv);
    pl_set_server_node(srv, pcp->param, \
	pcp->ip, pcp->port, pcp->value, down);
}

static void
pl_process_del_server(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_int_t rv = 0;
    pl_server_t *srv;
    srv = pl_get_server_node(pcp->param, 0);
    if( srv==NULL ) {
	rv = -1;
    } else {
	pl_int_t down;
	pl_get_stat_value(&(srv->info), \
	    VDOWN, &down, sizeof(down));
	if( !down ) {
	    rv = -1;
	}
    }
    if( proc==MASTER ) {
	pl_send_package_num(ps, rv);
	if( rv<0 ) {
	    return ;
	} else {
	    pl_deliver_msg(pcp);
	}
    }
    pl_del_all_sock_list(srv);
    pl_clean_cache_by_server(srv);
    pl_del_server_node(srv);
}

static void
pl_process_add_acl(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_int_t rv = 0;
    pl_rule_t *pr = pl_ctl_acl_rule(pcp->value, \
	pcp->ip, pcp->status, pcp->param, ADDACL);
    if( pr==NULL ) {
	rv = -1;
    }
    if( proc==MASTER ) {
	pl_send_package_num(ps, rv);
	if( rv<0 ) {
	    return ;
	}
	pl_deliver_msg(pcp);
    }
}

static void
pl_process_del_acl(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_int_t rv = 0;
    pl_rule_t *pr = pl_ctl_acl_rule(pcp->value, \
			NULL, 0, NULL, DELACL);
    if( pr==NULL ) {
	rv = -1;
    }
    if( proc==MASTER ) {
	pl_send_package_num(ps, rv);
	if( rv<0 ) {
	    return ;
	}
	pl_deliver_msg(pcp);
    }
}

static void
pl_process_set_server(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_int_t rv = 0;
    pl_server_t *srv;
    srv = pl_get_server_node(pcp->param, 0);
    if( srv==NULL ) {
	rv = -1;
    }
    if( proc==MASTER ) {
	pl_send_package_num(ps, rv);
	if( rv<0 ) {
		return ;
	}
	pl_deliver_msg(pcp);
    }
    pl_int_t down = 0;
    if( pcp->status==DOWN ) {
	down = 1;
    }
    pl_set_server_node(srv, pcp->param, \
	pcp->ip, pcp->port, pcp->value, down);
}

static void
pl_process_set_acl(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_int_t rv = 0;
    pl_rule_t *pr;
    pr = pl_ctl_acl_rule(pcp->value, \
		pcp->ip, pcp->status, \
		pcp->param, MODACL);
    if( pr==NULL ) {
	rv = -1;
    }
    if( proc==MASTER ) {
	pl_send_package_num(ps, rv);
	if( rv<0 ) {
	    return ;
	}
	pl_deliver_msg(pcp);
    }
}

static void
pl_process_access(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t nr_acl;
    nr_acl = pl_get_nr_acl();
    pl_chain_t *pc;
    pc = pl_create_chain_node();
    pl_add_chain_node(&nr_acl, \
	sizeof(nr_acl), ps, pc);
    pl_rule_t *pr = pl_get_acllist();
    while( pr!=NULL ) {
	pc = pl_create_chain_node();
	pl_add_chain_node(pr, \
	    sizeof(pl_rule_t), ps, pc);
	pr = pr->next;
    }
    pl_ctl_event(ps, EPOLLOUT, MOD);
}

static void
pl_process_set_lba(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_int_t rv = 0;
    pl_close_lib();
    if( !pl_init_dynamic_lib() ) {
	if( pl_set_algorithm(pcp->param)<0 ) {
	    rv = -1;
	}
    } else {
	pl_log(DEBUG, "pl_process_set_lba():\
switch to roundrobin.");
	rv = -2;
	pl_set_algorithm("roundrobin");
    }
    if( proc==MASTER ) {
	pl_send_package_num(ps, rv);
	if( rv==-1 ) {
	    return ;
	}
	pl_deliver_msg(pcp);
    } else {
	if( rv==-1 ) {
	    pl_log(DEBUG, "pl_process_set_lba():\
 PID:%d Cannot find %s. Switch to roundrobin.", \
	    getpid(), pcp->param);
	    pl_set_algorithm("roundrobin");
	}
    }
    if( !strcasecmp(pcp->param, "iphash") ) {
	pl_clean_hash_table();
    }
}

static void
pl_process_server(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_int_t rv;
    if( proc==MASTER ) {
	rv = pl_get_nr_server();
	rv = rv*pl_get_nr_proc();
	pl_send_package_num(ps, rv);
	if( rv!=0 ) {
	    pl_deliver_msg(pcp);
	}
	return ;
    }
    pl_chain_t *pc;
    pl_server_t *srv = pl_get_server_list();
    pl_proc_t *pp = pl_get_proc_list();
    pl_time_t idle, end;
    end = time(NULL);
    rv = pl_get_nr_server();
    pc = pl_create_chain_node();
    pl_add_chain_node(&rv, sizeof(rv), pp->ps, pc);
    pl_statinfo_t stif;
    while( srv!=NULL ) {
	memcpy(&stif, &(srv->info), sizeof(stif));
	pl_get_stat_value(&(srv->info), \
	    VIDLE, &idle, sizeof(idle));
	if( idle ) {
	    idle = end - idle;
	}
	pl_stat_ctl(&stif, IDLE, VALUE, idle);
	pc = pl_create_chain_node();
	pl_add_chain_node(&stif, \
	    sizeof(pl_statinfo_t), pp->ps, pc);
	srv = srv->next;
    }
    pl_ctl_event(pp->ps, EPOLLOUT, MOD);
}

static void
pl_process_client(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_int_t proc = pl_get_proc_type();
    pl_int_t rv;
    if( proc==MASTER ) {
	rv = pl_get_nr_proc();
	pl_send_package_num(ps, rv);
	if( rv!=0 ) {
	    pl_deliver_msg(pcp);
	}
	return ;
    }
    pl_proc_t *pp = pl_get_proc_list();
    pl_time_t idle, end;
    end = time(NULL);
    rv = 1;
    pl_chain_t *pc = pl_create_chain_node();
    pl_add_chain_node(&rv, sizeof(rv), pp->ps, pc);
    pl_statinfo_t stif;
    memcpy(&stif, &clientinfo, sizeof(stif));
    pl_get_stat_value(&clientinfo, \
	VIDLE, &idle, sizeof(idle));
    if( idle ) {
	idle = end - idle;
    }
    pl_stat_ctl(&stif, IDLE, VALUE, idle);
    pc = pl_create_chain_node();
    pl_add_chain_node(&stif, \
	sizeof(pl_statinfo_t), pp->ps, pc);
    pl_ctl_event(pp->ps, EPOLLOUT, MOD);
}

static void
pl_process_add_proc(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    pl_send_package_num(ps, 0);
    nr_restart++;
}

static void
pl_process_turn_restart(pl_socket_t *ps, \
	pl_console_package_t *pcp)
{
    if( pcp->status==ON ) {
	pl_stat_ctl(&clientinfo, \
		DOWNSTATUS, VALUE, 0);
    } else {
	pl_stat_ctl(&clientinfo, \
		DOWNSTATUS, VALUE, 1);
    }
    pl_send_package_num(ps, 0);
}
/*---------------end process---------------*/

void pl_master_ipc_send(pl_socket_t *ps, \
	const pl_char_t *func)
{
    pl_console_send(ps, func);
}

void pl_worker_ipc_recv(pl_socket_t *ps, \
	const pl_char_t *func)
{
    pl_console_recv(ps, func);
}

void pl_worker_ipc_send(pl_socket_t *ps, \
	const pl_char_t *func)
{
    pl_console_send(ps, func);
}

void pl_master_ipc_recv(pl_socket_t *ps, \
	const pl_char_t *func)
{
    pl_int_t n, size;
    pl_char_t *p, buf[BUFFER];
    if( ps->packlen<sizeof(ps->nr_answer) ) {
	size = sizeof(ps->nr_answer) - ps->packlen;
	p = (pl_char_t *)&ps->nr_answer + ps->packlen;
    } else {
	if( cmd==SERVER || cmd==CLIENT ) {
	    size = sizeof(pl_statinfo_t);
	} else {
	    size = BUFFER;	/*@ if you wanna add some 
				other commands which need 
				child process to answer, 
				you can change this variable
				to set the correct size*/
	}
	if( ps->pc_tail==NULL || ps->pc_tail->size==size ) {
	    memset(buf, 0, BUFFER);
	    p = buf;
	} else {
	    p = ps->pc_tail->buf + ps->pc_tail->size;
	    size -= ps->pc_tail->size;
	}
    }
    n = read(ps->sockfd, p, size);
    if( n<0 ) {
	pl_log(EMERGE, "%s: read error. %s.", \
	func, strerror(errno));
    } else if( n==0 ) {
	pl_log(DEBUG, "%s: child process dead.", func);
	nr_restart++;
	pl_del_proc_node_socket(ps);
	pl_close_socket(ps, 0);
	pl_set_nr_proc(pl_get_nr_proc()-1);
    }
    if( ps->packlen<sizeof(ps->nr_answer) ) {
	ps->packlen += n;
	if( ps->packlen==sizeof(ps->nr_answer) ) {
	    if( ps->nr_answer==0 ) {
		ps->nr_answer = 0;
		ps->packlen = 0;
		nr_restart++;
	    }
	}
	return ;
    }
    if( ps->pc_tail!=NULL && ps->pc_tail->size!=size ) {
	ps->pc_tail->size += n;
	if( n==size ) {
	    if( !(--(ps->nr_answer)) ) {
		ps->packlen = 0;
		pl_ctl_event(psconsole, EPOLLOUT, MOD);
	    }
	}
	return ;
    }
    pl_chain_t *pc;
    pc = pl_create_chain_node();
    pl_add_chain_node(buf, n, psconsole, pc);
    if( n==size ) {
	if( !(--(ps->nr_answer)) ) {
	    ps->packlen = 0;
	    pl_ctl_event(psconsole, EPOLLOUT, MOD);
	}
    }
}

static void pl_deliver_msg(pl_console_package_t *pcp)
{
    pl_proc_t *pp = pl_get_proc_list();
    pl_chain_t *pc;
    while( pp!=NULL ) {
	pc = pl_create_chain_node();
	pl_add_chain_node(pcp, \
	sizeof(pl_console_package_t), pp->ps, pc);
	pl_ctl_event(pp->ps, EPOLLOUT, MOD);
	pp = pp->next;
    }
}

void pl_send_package_num(pl_socket_t *ps, pl_int_t num)
{
    pl_chain_t *pc;
    pc = pl_create_chain_node();
    pl_add_chain_node(&num, sizeof(num), ps, pc);
    pl_ctl_event(ps, EPOLLOUT, MOD);
}

