
/*
 * Copyright (C) Niklaus F.Schen.
 */

#define __CONSOLE
#include"pl_console.h"
#include"pl_alloc.h"
#include"pl_conf.h"
#include"pl_access.h"
#include<unistd.h>
#include<sys/epoll.h>
#include<string.h>
#include<errno.h>
#include<stdio.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<stdlib.h>
#include<signal.h>

/*local function declarations*/
static void pl_console_init(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_get_parameters(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_show_help(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_show_version(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_turn_server(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_turn_acl(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_add_server(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_del_server(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_add_acl(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_del_acl(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_set_server(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_set_acl(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_set_lba(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_turn_restart(pl_int_t argc, \
			pl_char_t *argv[]);
static void pl_send_and_recv(void);
static pl_chain_t *pl_create_chain(void);
static void pl_add_chain(pl_char_t *str, \
		pl_int_t size, pl_chain_t *pc);
/*static void pl_del_chain(pl_chain_t *pc);*/
static void pl_process_package(void);
static pl_char_t *pl_ip_itoa(pl_uint_t ip);
static void pl_process_access(void);
static void pl_process_server(void);
static void pl_process_client(void);

static void pl_accumulate(pl_statinfo_t *dest, \
	pl_statinfo_t *src);
void pl_print_size_unit(pl_ullong_t data);
static void pl_print_all_info(pl_statinfo_t *pst);
/*static variables*/
pl_char_t srvip[IPADDR];
pl_char_t transip[IPADDR];
pl_ushort_t srvport;
pl_int_t epfd, connectfd;
pl_int_t nr_pack;
pl_int_t nr_proc;
pl_pool_t *pool;
pl_chain_t *pc_head = NULL, *pc_tail = NULL;
pl_console_package_t msg;
pl_char_t error[] = "Parameter error. Please use '--help' to search all commands.";
pl_char_t cmd_table[NR_CMD][COLUME] = \
{"--help", "--version", "quit", "clear", \
"turnsrv", "turnacl", "addsrv", "delsrv", \
"addacl", "delacl", "setsrv", "setacl", \
"access", "setlba", "server", "client", \
"addproc", "turnrestart"};/*NR_CMD = 17*/
pl_char_t blockstring[BLOCKARG][BLOCKSTR] = \
{"pl_stat_ctl", "pl_get_stat_value", \
"pl_init_stat_min_value", "pl_init_log", \
"pl_log", "pl_load_conf", "pl_nr_expression_check", \
"pl_get_conf", "pl_get_current_domain", \
"pl_check_nr_expression", "pl_create_pool", \
"pl_alloc", "pl_free", "pl_destory_pool", \
"pl_slice", "pl_slicev", "pl_end_slice"
};

int main(int argc, char *argv[])
{
    pl_load_conf("conf/probalance.conf");
    pl_console_init(argc, argv);
    pl_send_and_recv();
    pl_process_package();
    exit(0);
}

static void pl_console_init(pl_int_t argc, \
			pl_char_t *argv[])
{
    /*clean*/
    memset(srvip, 0, IPADDR);
    memset(&msg, 0, sizeof(msg));
    msg.cmd = -1;
    /*get parameters*/
    pl_get_parameters(argc, argv);
    /*get ip and port*/
    pl_domain_t *pd = pl_get_current_domain();
    pl_var_t *pv = \
	pl_get_conf(pd->domain, "server_ip", VAR);
    if( pv==NULL ) {
	fprintf(stderr, "pl_console_init(): item \
'server_ip' in domain '%s' is not existed.\n", \
	pd->domain); exit(1);
    }
    if( pv->type!=STR ) {
	fprintf(stderr, "pl_console_init(): type \
of 'server_ip' in domain '%s' is error.\n", \
	pd->domain); exit(1);
    }
    strcpy(srvip, pv->data.str);
    pv = pl_get_conf(pd->domain, "server_port", VAR);
    if( pv==NULL ) {
	fprintf(stderr, "pl_console_init(): item \
'server_port' in domain '%s' is not existed.\n", \
	pd->domain); exit(1);
    }
    if( pv->type!=INT ) {
	fprintf(stderr, "pl_console_init(): type \
of item 'server_port' in domain '%s' is error.\n", \
	pd->domain); exit(1);
    }
    srvport = pv->data.value;
    /*create pool*/
    pool = pl_create_pool();
    /*preparation for socket and connect*/
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(srvport);
    addr.sin_addr.s_addr = inet_addr(srvip);
    connectfd = socket(AF_INET, SOCK_STREAM, 0);
    if( connectfd<0 ) {
	fprintf(stderr, \
	"pl_console_init(): socket error. %s.\n", \
	strerror(errno)); exit(1);
    }
    if( connect(connectfd, (struct sockaddr *)&addr, \
	sizeof(addr))<0 )
    {
	fprintf(stderr, \
	"pl_console_init(): connect error. %s.\n", \
	strerror(errno)); exit(1);
    }
}

static void pl_get_parameters(pl_int_t argc, \
			    pl_char_t *argv[])
{
    if( argc==1 )
	goto err;
    pl_int_t i;
    for(i = 0; i<NR_CMD; i++) {
	if( !strcmp(argv[1], cmd_table[i]) ) {
	    msg.cmd = i;
	    break;
	}
    }
    switch( msg.cmd ) {
	case HELP:
		pl_show_help(argc, argv);
		break;
	case VERSION:
		pl_show_version(argc, argv);
		break;
	case TURNSRV:
		pl_turn_server(argc, argv);
		break;
	case TURNACL:
		pl_turn_acl(argc, argv);
		break;
	case ADDSRV:
		pl_add_server(argc, argv);
		break;
	case DELSRV:
		pl_del_server(argc, argv);
		break;
	case ADDACL:
		pl_add_acl(argc, argv);
		break;
	case DELACL:
		pl_del_acl(argc, argv);
		break;
	case SETSRV:
		pl_set_server(argc, argv);
		break;
	case SETACL:
		pl_set_acl(argc, argv);
		break;
	case SETLBA:
		pl_set_lba(argc, argv);
		break;
	case TURNRESTART:
		pl_turn_restart(argc, argv);
		break;
	case QUIT:
	case CLEAR:
	case ACCESS:
	case SERVER:
	case CLIENT:
	case ADDPROC:
		break;
	default:
err:		fprintf(stderr, "%s\n", error);
		exit(1);
    }
}

static void
pl_show_help(pl_int_t argc, \
	pl_char_t *argv[])
{
    if( argc!=2 ) {
	fprintf(stderr, "%s\n", error);
	exit(1);
    }
    printf("Welcome to ProBalance.\n");
    printf("Formate: %s command [parameters]\nCommands:\n", argv[0]);
    printf("--version\t\t\t\tshow ProList Load Balancer's version.\n");
    printf("quit\t\t\t\t\tkill ProList Load Balancer.\n");
    printf("clear\t\t\t\t\tclean all informations up.\n");
    printf("turnsrv server up|down\t\t\tchange the server's status.\n");
    printf("turnacl on|off\t\t\t\tchange the status of the ACL.\n");
    printf("addsrv server ip port weight up|down\tadd a back-end server.\n");
    printf("delsrv server\t\t\t\tdel a back-end server.\n");
    printf("addacl num ip netbit rule\t\tadd an ACL rule.\n");
    printf("delacl num\t\t\t\tdel an ACL rule.\n");
    printf("setsrv server ip port weight up|down\tmodify the server's informations.\n");
    printf("setacl num ip netbit rule\t\tmodify the ACL rule.\n");
    printf("access\t\t\t\t\tshow all ACL rules.\n");
    printf("setlba algorithm\t\t\tset a load balancing algorithm.\n");
    printf("server\t\t\t\t\tshow all servers' informations.\n");
    printf("client\t\t\t\t\tshow all clients' informations.\n");
    printf("addproc\t\t\t\t\tadd a worker process.\n");
    printf("turnrestart on|off\t\t\tswitch of restarting worker process.\n");
    exit(0);
}

static void
pl_show_version(pl_int_t argc, pl_char_t *argv[])
{
    if( argc!=2 ) {
	fprintf(stderr, "%s\n", error);
	exit(1);
    }
    printf("ProList Load Balancer. Version 1.0.\n");
    exit(0);
}

static void
pl_turn_server(pl_int_t argc, pl_char_t *argv[])
{
    if( argc!=4 ) {
err:	fprintf(stderr, "%s\n", error);
	exit(1);
    }
    strcpy(msg.param, argv[2]);
    if( !strcasecmp(argv[3], "up") ) {
	msg.status = UP;
    } else if( !strcasecmp(argv[3], "down") ) {
	msg.status = DOWN;
    } else {
	goto err;
    }
}

static void
pl_turn_acl(pl_int_t argc, pl_char_t *argv[])
{
    if( argc!=3 ) {
err:	fprintf(stderr, "%s\n", error);
	exit(1);
    }
    if( !strcasecmp(argv[2], "on") ) {
	msg.status = ON;
    } else if( !strcasecmp(argv[2], "off") ) {
	msg.status = OFF;
    } else {
	goto err;
    }
}

static void
pl_add_server(pl_int_t argc, pl_char_t *argv[])
{
    if( argc!=7 ) {
err:	fprintf(stderr, "%s\n", error);
	exit(1);
    }
    strcpy(msg.param, argv[2]);
    strcpy(msg.ip, argv[3]);
    msg.port = atoi(argv[4]);
    msg.value = atoi(argv[5]);
    if( !strcasecmp(argv[6], "up") ) {
	msg.status = UP;
    } else if( !strcasecmp(argv[6], "down") ) {
	msg.status = DOWN;
    } else {
	goto err;
    }
}

static void
pl_del_server(pl_int_t argc, pl_char_t *argv[])
{
    if( argc!=3 ) {
	fprintf(stderr, "%s\n", error);
	exit(1);
    }
    strcpy(msg.param, argv[2]);
}

static void
pl_add_acl(pl_int_t argc, pl_char_t *argv[])
{
    if( argc<5 || argc>6 ) {
err:	fprintf(stderr, "%s\n", error);
	exit(1);
    }
    pl_int_t i = 2;
    if( argc==6 ) {
	msg.value = atoi(argv[i++]);
	if( msg.value<0 )
	    goto err;
    } else {
	msg.value = -1;
    }
    strcpy(msg.ip, argv[i++]);
    msg.status = atoi(argv[i++]);
    if( msg.status>32 ) {
	goto err;
    }
    if( strcasecmp(argv[i], "deny") && \
	strcasecmp(argv[i], "allow") )
    {
	goto err;
    }
    strcpy(msg.param, argv[i]);
}

static void
pl_del_acl(pl_int_t argc, pl_char_t *argv[])
{
    if( argc!=3 ) {
err:	fprintf(stderr, "%s\n", error);
	exit(1);
    }
    msg.value = atoi(argv[2]);
    if( msg.value<0 ) {
	goto err;
    }
}

static void
pl_set_server(pl_int_t argc, pl_char_t *argv[])
{
    pl_add_server(argc, argv);
}

static void
pl_set_acl(pl_int_t argc, pl_char_t *argv[])
{
    pl_add_acl(argc, argv);
    if( msg.value<0 ) {
	fprintf(stderr, "%s\n", error);
	exit(1);
    }
}

static void
pl_set_lba(pl_int_t argc, pl_char_t *argv[])
{
    if( argc!=3 ) {
err:	fprintf(stderr, "%s\n", error);
	exit(1);
    }
    pl_int_t i;
    for(i = 0; i<BLOCKARG; i++) {
	if( !strcasecmp(argv[2], blockstring[i]) )
		goto err;
    }
    strcpy(msg.param, argv[2]);
}

static void
pl_turn_restart(pl_int_t argc, pl_char_t *argv[])
{
    if( argc!=3 ) {
err:	fprintf(stderr, "%s\n", error);
	exit(1);
    }
    if( !strcasecmp(argv[2], "on") ) {
	msg.status = ON;
    } else if( !strcasecmp(argv[2], "off") ) {
	msg.status = OFF;
    } else {
	goto err;
    }
}

static pl_chain_t *pl_create_chain(void)
{
    pl_chain_t *pc;
    pc = pl_alloc(pool, sizeof(pl_chain_t));
    if( pc==NULL ) {
	fprintf(stderr, \
	"pl_create_chain(): allocate pl_chain_t error.\n");
	exit(1);
    }
    return pc;
}

static void pl_add_chain(pl_char_t *str, \
	pl_int_t size, pl_chain_t *pc)
{
    if( pc_head==NULL ) {
	pc_head = pc_tail = pc;
    } else {
	pc_tail->next = pc;
	pc_tail = pc;
    }
    pl_char_t *buf;
    buf = pl_alloc(pool, size);
    if( buf==NULL ) {
	fprintf(stderr, \
	"pl_add_chain(): allocate %d block error.\n", \
	size); exit(1);
    }
    memcpy(buf, str, size);
    pc->buf = buf;
}

/*static void pl_del_chain(pl_chain_t *pc)
{
	if( pc!=pc_head ) {
		fprintf(stderr, \
		"pl_del_chain(): the sequence of del-chain is error.\n");
		exit(1);
	}
	pc_head = pc->next;
	if( pc_head==NULL ) {
		pc_tail = NULL;
	}
	if( pl_free(pc->buf)<0 ) {
		fprintf(stderr, \
		"pl_del_chain(): pl_free BUF error.\n");
		exit(1);
	}
	if( pl_free(pc)<0 ) {
		fprintf(stderr, \
		"pl_del_chain(): pl_free pl_chain_t error.\n");
		exit(1);
	}
}*/

static void
pl_send_and_recv(void)
{
    pl_int_t n;
    pl_char_t buf[BUFLEN];
    memset(buf, 0, BUFLEN);
    n = write(connectfd, &msg, sizeof(msg));
    if( n!=sizeof(msg) ) {
	fprintf(stderr, \
	"pl_send_and_recv(): send error. %s.\n", \
	strerror(errno)); exit(1);
    }
    n = read(connectfd, buf, sizeof(nr_pack));
    if( n<0 ) {
err:	fprintf(stderr, \
	"pl_send_and_recv(): recv error.%s.\n", \
	strerror(errno)); exit(0);
    } else if( n==0 ) {
	if( msg.cmd==QUIT )
	    exit(0);
bre:	fprintf(stderr, \
	"pl_send_and_recv(): connection is broken.\n");
	exit(1);
    }
    nr_pack = *(pl_int_t *)buf;
    if( nr_pack==-1 ) {
	printf("Command '%s' failed.\n", cmd_table[msg.cmd]);
	exit(0);
    } else if( nr_pack<0 ) {
	printf("Dynamic library lost. Switch to roundrobin.\n");
	exit(0);
    } else if( nr_pack==0 ) {
	exit(0);
    }
    if( msg.cmd==CLIENT ) {
	nr_proc = nr_pack;
    }
    pl_int_t i, size;
    pl_char_t *p;
    if( msg.cmd==ACCESS ) {
	size = sizeof(pl_rule_t);
    } else {
	size = sizeof(pl_statinfo_t);
    }
    for(i = 0; i<nr_pack; i++) {
	memset(buf, 0, BUFLEN);
	p = buf;
lp:	n = read(connectfd, p, size);
	if( n<0 ) {
	    goto err;
	} else if( n==0 ) {
	    goto bre;
	} else {
	    p += n;
	    if( n!=size ) {
		size -= n;
		goto lp;
	    }
	}
	pl_chain_t *pc;
	pc = pl_create_chain();
	pl_add_chain(buf, p-buf, pc);
    }
}

static void pl_process_package(void)
{
    switch( msg.cmd ) {
	case CLEAR:
	case TURNSRV:
	case TURNACL:
	case ADDSRV:
	case DELSRV:
	case ADDACL:
	case DELACL:
	case SETSRV:
	case SETACL:
	case SETLBA:
	case ADDPROC:
	case TURNRESTART:
	    fprintf(stderr, \
	    "pl_process_package(): shouldn't be here.\n");
	    exit(1);
	case ACCESS:
	    pl_process_access();
	    break;
	case SERVER:
	    pl_process_server();
	    break;
	case CLIENT:
	    pl_process_client();
	    break;
    }
}

static void pl_process_access(void)
{
    pl_chain_t *pc = pc_head;
    pl_rule_t *pr;
    pl_char_t buf[16];
    pl_int_t netbit;
    while( pc!=NULL ) {
	memset(buf, 0, 16);
	pr = (pl_rule_t *)(pc->buf);
	if( pr->rule==DENY ) {
	    strcpy(buf, "deny");
	} else {
	    strcpy(buf, "allow");
	}
	netbit = ~(pr->nr_ip);
	if( netbit==0 ) {
	    netbit = 0;
	} else if( netbit==((pl_int_t)(~0)) ) {
	    netbit = 32;
	} else {
	    pl_int_t i;
	    for(i = IPADDR - 1; i>=0; i--) {
		if( !((netbit>>i)&1) ) {
		    break;
		}
	    }
	    netbit = IPADDR - i - 1;
	}
	printf("No.%d IP:%s/%d RULE:%s\n", \
	pr->num, pl_ip_itoa(pr->ip), netbit, buf);
	pc = pc->next;
    }
}

static pl_char_t *pl_ip_itoa(pl_uint_t ip)
{
	memset(transip, 0, IPADDR);
	sprintf(transip, "%d.%d.%d.%d", \
		(ip>>24)&0xff, (ip>>16)&0xff, \
		(ip>>8)&0xff, ip&0xff);
	return transip;
}

static void pl_process_server(void)
{
    pl_chain_t *pc = pc_head;
    pl_statinfo_t *pst;
    pl_sum_info_t *list = NULL, *scan, *tail = NULL;
    while( pc!=NULL ) {
	pst = (pl_statinfo_t *)(pc->buf);
	for(scan = list; scan!=NULL; scan = scan->next) {
	    if( !strcmp(pst->name, scan->info.name) ) {
		pl_accumulate(&(scan->info), pst);
		break;
	    }
	}
	if( scan==NULL ) {
	    scan = pl_alloc(pool, sizeof(pl_sum_info_t));
	    if( scan==NULL ) {
		fprintf(stderr, "pl_process_server(): \
allocate pl_sum_info_t error.\n"); exit(1);
	    }
	    memcpy(&(scan->info), pst, sizeof(pl_statinfo_t));
	    if( list==NULL ) {
		list = tail = scan;
	    } else {
		tail->next = scan;
		tail = scan;
	    }
	}
	pc = pc->next;
    }
    for(scan = list; scan!=NULL; scan = scan->next) {
	pl_print_all_info(&(scan->info));
	printf("\n");
    }
}

static void pl_process_client(void)
{
	pl_chain_t *pc = pc_head->next;
	pl_statinfo_t *pst1 = (pl_statinfo_t *)(pc_head->buf);
	pl_statinfo_t *pst2;
	while( pc!=NULL ) {
		pst2 = (pl_statinfo_t *)(pc->buf);
		pl_accumulate(pst1, pst2);
		pc = pc->next;
	}
	strcpy(pst1->name, "client");
	pl_print_all_info(pst1);
}

static void
pl_accumulate(pl_statinfo_t *dest, pl_statinfo_t *src)
{
    dest->in += src->in;
    dest->out += src->out;
    if( src->max_in_data>dest->max_in_data ) {
	dest->max_in_data = src->max_in_data;
    }
    if( src->max_out_data>dest->max_out_data ) {
	dest->max_out_data = src->max_out_data;
    }
    if( src->min_time_per_connection<\
	dest->min_time_per_connection )
    {
	dest->min_time_per_connection = \
		src->min_time_per_connection;
    }
    if( src->max_time_per_connection>\
	dest->max_time_per_connection )
    {
	dest->max_time_per_connection = \
		src->max_time_per_connection;
    }
    dest->all_time += src->all_time;
    dest->nr_notrans += src->nr_notrans;
    dest->sum_connections += src->sum_connections;
    dest->current_connections += src->current_connections;
    dest->failed_connections += src->failed_connections;
    if( src->idle<dest->idle ) {
	dest->idle = src->idle;
    }
}

void pl_print_size_unit(pl_ullong_t data)
{
	pl_int_t i = 4;
	while( data>1024 && i ) {
		data /= 1024;
		i--;
	}
	printf("%lld ", data);
	switch( i ) {
		case 4:
			printf("Byte");
			break;
		case 3:
			printf("KB");
			break;
		case 2:
			printf("MB");
			break;
		case 1:
			printf("GB");
			break;
		case 0:
			printf("TB");
			break;
	}
	printf("\n");
}

static void pl_print_all_info(pl_statinfo_t *pst)
{
    if( msg.cmd==CLIENT ) {
	printf("NRPROCESS:%d\n", nr_proc);
    }
    printf("NAME:%s\n", pst->name);
    printf("\tIN:");
    pl_print_size_unit(pst->in);
    printf("\tOUT:");
    pl_print_size_unit(pst->out);
    printf("\tONCE MAX IN:");
    pl_print_size_unit(pst->max_in_data);
    printf("\tONCE MAX OUT:");
    pl_print_size_unit(pst->max_out_data);
    if( pst->min_time_per_connection==~0 ) {
	printf("\tMIN RESPONSE TIME:0.000(ms)\n");
    } else {
	printf("\tMIN RESPONSE TIME:%.3f(ms)\n", \
	((float)(pst->min_time_per_connection))/1000);
    }
    printf("\tMAX RESPONSE TIME:%.3f(ms)\n", \
	((float)(pst->max_time_per_connection))/1000);
    printf("\tAVERAGE RESPONSE TIME:");
    if( !pst->sum_connections ) {
	printf("0.000(ms)\n");
    } else if( pst->sum_connections<3 ) {
	printf("%.3f(ms)\n", \
	((float)(pst->all_time))/pst->sum_connections/1000);
    } else {
	printf("%.3f(ms)\n", \
	((float)(pst->all_time - pst->max_time_per_connection - \
	pst->min_time_per_connection)) / (pst->sum_connections-2)/1000);
    }
    printf("\tNO TRANS:%lld\n", pst->nr_notrans);
    printf("\tFINISHED CONNECTIONS:%lld\n", pst->sum_connections);
    printf("\tCURRENT CONNECTIONS:%lld\n", pst->current_connections);
    printf("\tFAILED CONNECTIONS:%lld\n", pst->failed_connections);
    printf("\tWEIGHT:%d\n", pst->weight);
    printf("\tDOWN:");
    if( pst->down ) {
	printf("down\n");
    } else {
	printf("up\n");
    }
    printf("\tIDLE:%d(s)\n", (pl_int_t)(pst->idle));
}

