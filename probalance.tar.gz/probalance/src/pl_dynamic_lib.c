
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_dynamic_lib.h"
#include"pl_log.h"
#include<dlfcn.h>
#include<stdio.h>
#include<string.h>
/*local function declarations*/

/*static variables*/
static void *dl_handle = NULL;

pl_int_t pl_init_dynamic_lib(void)
{
    dl_handle = dlopen("./pllib.so", RTLD_NOW);
    if( dl_handle==NULL ) {
	pl_log(DEBUG, "pl_init_dynamic_lib():\
 dl_open error. %s.", dlerror());
	return -1;
    }
    return 0;
}

pl_int_t
pl_chech_dynamic_lib(const pl_char_t *algname)
{
    if( !strcmp(algname, "roundrobin") || \
	!strcmp(algname, "iphash") )
	return 0;
    void *ptr = NULL;
    ptr = dlsym(dl_handle, algname);
    if( ptr==NULL ) {
	pl_log(DEBUG, "pl_check_dynamic_lib():%s. %s.", \
	algname, dlerror());
	return -1;
    }
    return 0;
}

void *pl_return_alptr(const pl_char_t *alname)
{
    void *ptr = NULL;
    ptr = dlsym(dl_handle, alname);
    return ptr;
}

void pl_close_lib(void)
{
    if( dl_handle==NULL ) {
	pl_log(DEBUG, \
	"pl_close_lib(): no lib.");
	return ;
    }
    if( dlclose(dl_handle)!=0 )
	pl_log(EMERGE, \
	"pl_close_lib(): %s.", \
	dlerror());
}

