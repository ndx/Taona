
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_dynamic_lib.h"
#include"pl_event.h"
#include"pl_conf.h"
#include"pl_fork.h"
#include"pl_server.h"
#include"pl_access.h"
#include"pl_io.h"
#include"pl_syslimit.h"
#include"pl_log.h"
#include"pl_statistics.h"
#include"pl_global.h"
#include"pl_lock.h"
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<errno.h>
#include<time.h>
/*local function declarations*/
static void pl_event_init(void);
static pl_int_t pl_event_create(void);
static pl_int_t pl_event_wait(pl_event_t *pe);
static pl_int_t pl_adjust(pl_char_t *argv[]);
static void pl_event_handler(pl_int_t nfds, \
				pl_event_t *pe);
static void pl_preprocedure_io(pl_event_t *pe, \
				pl_int_t flg);
static void pl_accept(pl_socket_t *ps);
static void pl_connect(pl_bind_t *pb, \
			pl_socket_t *acc);
static void pl_check_connection_status(pl_socket_t *ps);
static void pl_io(pl_socket_t *ps, pl_int_t flg);
static void pl_epollerr(pl_event_t *pe);

/*static variables*/
static pl_int_t epfd = 0, proc;
static pl_int_t event_limit;
static pl_int_t use_cache;
static pl_int_t acl_status;
static pl_int_t overload_times = 0;
static pl_socket_t *plisten;
static pl_algorithm_data_t ad;

pl_int_t pl_event(pl_char_t *argv[])
{
    pl_event_t events[EVENTSIZE];
    pl_int_t nfds;
    if( epfd ) {
	close(epfd);
	epfd = 0;
    }
    epfd = pl_event_create();
    pl_event_init();
    while( 1 ) {
	if( pl_adjust(argv)<0 ) {
	    return WORKER;
	}
	if( nr_restart>0 )
	    continue;
	nfds = pl_event_wait(events);
	if( nfds<0 ) {
	    continue;
	}
	pl_event_handler(nfds, events);
    }
    return MASTER;
}

static pl_int_t pl_event_create(void)
{
    epfd = epoll_create(EVENTSIZE);
    if( epfd<0 )
	pl_log(EMERGE, \
	"pl_event_create(): epoll_create error. %s", \
	strerror(errno));
    return epfd;
}

static pl_int_t pl_event_wait(pl_event_t *pe)
{
    pl_int_t rv;
    rv = epoll_wait(epfd, pe, EVENTSIZE, -1);
    if( rv<0 && errno==EINTR ) {
	return -1;
    }
    else if( rv<0 ) {
	pl_log(EMERGE, \
	"pl_event_wait(): epoll_wait error. %s.", \
	strerror(errno));
    }
    return rv;
}

static void pl_event_init(void)
{
    /*console*/
    console_existed = 0;
    /*init statistics*/
    memset(&clientinfo, 0, sizeof(pl_statinfo_t));
    /*close and clean connection_cache*/
    use_cache = pl_get_connection_cache_status();
    pl_clean_all_cache();
    pl_init_cache_stuff();
    /*get work_connections conf*/
    pl_int_t work_connections = \
	pl_get_work_connections();
    event_limit = (work_connections>>4)*7;
    /*get process type*/
    proc = pl_get_proc_type();
    /*clean bind chain*/
    pl_bind_t *pb = pl_get_bind();
    for(; pb!=NULL; pb = pb->next) {
	if( proc==MASTER && \
	    pb->s[COMMON].type==LISTEN )
	{
	    continue;
	} else if( pb->s[COMMON].type==LISTEN ) {
	    plisten = &(pb->s[COMMON]);
	}
	pl_ctl_event(&(pb->s[COMMON]), EPOLLIN, ADD);
    }
    /*set idle*/
    pl_time_t tm = time(NULL);
    pl_stat_ctl(&clientinfo, IDLE, VALUE, tm);
    pl_init_stat_min_value(&clientinfo);
    pl_set_server_idle();
    /*init pl_algorithm_data_t*/
    memset(&ad, 0, sizeof(ad));
    /*init nr_restart*/
    nr_restart = 0;
}

static pl_int_t pl_adjust(pl_char_t *argv[])
{
    acl_status = pl_get_acl_status();
    if( nr_restart>0 ) {
	pl_int_t fd = MASTER;
	pl_socket_t *ps;
	pl_int_t limit = 0;
	if( pl_get_autoadjust() ) {
	    limit = pl_get_maxnrproc();
	}
	if( !limit || pl_get_nr_proc()<limit ) {
	    pl_int_t norestart;
	    pl_get_stat_value(&clientinfo, VDOWN, \
		&norestart, sizeof(norestart));
	    if( !norestart ) {
		fd = pl_fork_child(argv);
	    }
	}
	nr_restart--;
	if( fd==WORKER ) {
	    return -1;
	} else if( fd!=MASTER ) {
	    ps = pl_get_pair_sockfd(fd);
	    pl_ctl_event(ps, EPOLLIN, ADD);
	    pl_set_nr_proc(pl_get_nr_proc()+1);
	}
    }
    pl_clean_socket_memory();
    if( proc==WORKER ) {
	if( nr_fds>=event_limit ) {
	    pl_int_t autoadjust = pl_get_autoadjust();
	    if( autoadjust ) {
		if( overload_times++==OVERLOAD ) {
		    pl_proc_t *pp = pl_get_proc_list();
		    pl_send_package_num(pp->ps, 0);
		    overload_times = 0;
		}
	    }
	} else {
	    overload_times = 0;
	}
    }
    return 0;
}

static void pl_event_handler(pl_int_t nfds, pl_event_t *pe)
{
    pl_int_t i;
    for(i = 0; i<nfds; i++) {
	if( pe[i].events&EPOLLOUT ) {
	    pl_preprocedure_io(&(pe[i]), WR);
	}
	if( pe[i].events&EPOLLIN ) {
	    pl_preprocedure_io(&(pe[i]), RD);
	}
	if( pe[i].events&EPOLLERR ) {
	    pl_epollerr(&(pe[i]));
	}
    }
}

static void pl_epollerr(pl_event_t *pe)
{
    pl_socket_t *ps = (pl_socket_t *)(pe->data.ptr);
    if( ps->status==DEAD )
	return;
    pl_log(DEBUG, "pl_epollerr(): %s.", strerror(errno));
    pl_socket_t *other = pl_get_other_socket(ps);
    if( other->status!=DEAD ) {
	pl_ctl_event(other, EPOLLOUT|EPOLLONESHOT|EPOLLET, MOD);
    }
    pl_close_socket(ps, 0);
}

static void
pl_preprocedure_io(pl_event_t *pe, pl_int_t flg)
{
    pl_socket_t *ps = (pl_socket_t *)(pe->data.ptr);
    if( ps->status==INIT ){
	pl_check_connection_status(ps);
	return ;
    }
    if( ps->type==CONSOLE || ps->type==LISTEN ) {
	pl_accept(ps);
	return ;
    }
    if( flg==RD ) {
	pl_io(ps, RD);
    } else if( flg==WR ) {
	pl_io(ps, WR);
    } else {
	pl_log(EMERGE, \
	"pl_preprocedure_io(): no such flag.");
    }
}

static void pl_check_connection_status(pl_socket_t *ps)
{
    pl_int_t err, rv;
    socklen_t len = sizeof(err);
    pl_socket_t *theother = pl_get_other_socket(ps);
    rv = getsockopt(ps->sockfd, SOL_SOCKET, SO_ERROR, &err, &len);
    if( rv<0 ) {
	pl_log(ERROR, "pl_check_connection_status(): getsockopt \
error. %s.", strerror(errno));
    }
    if( err && err!=EINPROGRESS ) {
	if( err==ECONNREFUSED ) {
	    pl_stat_ctl(&(ps->srv->info), DOWNSTATUS, VALUE, 1);
	    if( use_cache ) {
		pl_clean_cache_by_server(ps->srv);
	    }
	}
	pl_log(DEBUG, "pl_check_connection_status(): socket status \
err. %s.", strerror(err));
	pl_stat_ctl(&(ps->srv->info), FAILED, INC, 0);
	pl_ullong_t cur_connections;
	pl_get_stat_value(&(ps->srv->info), VCURRENT, &cur_connections, \
						sizeof(cur_connections));
	if( !cur_connections ) {
	    pl_stat_ctl(&(ps->srv->info), IDLE, VALUE, time(NULL));
	}
	close(ps->sockfd);
	pl_del_sock_list(ps->srv, ps);
	if( theother->status!=DEAD ) {
	    close(theother->sockfd);
	    theother->status = DEAD;
	    pl_stat_ctl(&clientinfo, CURRENT, DEC, 0);
	}
	pl_stat_ctl(&(ps->srv->info), CURRENT, DEC, 0);
	ps->status = DEAD;
	nr_fds--;
	pl_del_from_queue(ps->pb);
    } else if( err ) {
	return ;
    } else {
	ps->status &= ~INIT;
	if( theother->status==DEAD ) {
		pl_close_socket(ps, 0);
	} else {
	    if( ps->pc==NULL ) {
		pl_ctl_event(ps, EPOLLIN|EPOLLONESHOT|EPOLLET, MOD);
		pl_ctl_event(theother, EPOLLIN|EPOLLONESHOT|EPOLLET, MOD);
	    } else {
		pl_ctl_event(ps, EPOLLOUT|EPOLLONESHOT|EPOLLET, MOD);
		ps->status |= SENDING;
	    }
	}
    }
}

static void pl_accept(pl_socket_t *ps)
{
    if( proc==WORKER ) {
	if( pl_add_lock()<0 ) {
	    return ;
	}
    }
    pl_int_t type = ps->type;
    pl_int_t connfd;
    pl_bind_t *pb;
    socklen_t len = sizeof(struct sockaddr);
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    while( (connfd = accept(ps->sockfd, \
	(struct sockaddr *)&addr, &len))>0 )
    {
	if( acl_status ) {
	    pl_char_t ip[IPLEN];
	    memset(ip, 0, IPLEN);
	    strcpy(ip, inet_ntoa(addr.sin_addr));
	    if( pl_test_acl(ip)<0 ) {
		if( proc==WORKER )
		    pl_stat_ctl(&clientinfo, FAILED, INC, 0);
		close(connfd);
		goto lp;
	    }
	}
	pl_setnonblock(connfd);
	if( proc==WORKER )
	    pl_tcp_nodelay(connfd);
	pb = pl_create_bind();
	pl_set_socket(&(pb->s[ACCEPT>>MOV]), ACCEPT|type, \
					&addr, pb, connfd);
	pl_add_in_queue(pb);
	memcpy(&(ad.addr), &addr, sizeof(addr));
	if( proc==MASTER ) {
	    if( !console_existed ) {
		pl_ctl_event(&(pb->s[CONSOLE>>MOV]), \
					EPOLLIN, ADD);
		console_existed = 1;
	    } else {
		 close(connfd);
	    }
	} else {
	    pl_stat_ctl(&clientinfo, IDLE, VALUE, 0);
	    pl_connect(pb, &(pb->s[ACCEPT>>MOV]));
	}
lp:	memset(&addr, 0, sizeof(addr));
    }
    if( connfd<0 ) {
	if( errno!=EAGAIN && errno!=EINTR && \
	    errno!=ECONNABORTED && errno!=EPROTO && \
	    errno!=EMFILE && errno!=ENFILE )
	    {
		pl_log(EMERGE, \
		"pl_accept(): accept error. %s.", \
		strerror(errno));
	    }
	if( errno==EAGAIN ) {
	    if( proc==WORKER ) {
		pl_unlock();
	    }
	}
    }
}

static void pl_connect(pl_bind_t *pb, pl_socket_t *acc)
{
    pl_server_t *srv = NULL;
    pl_int_t fd, rv, status = 0;
    if( use_cache ) {
	pl_uint_t remain = alarm(0);
	if( !remain ) {
	    remain = 1;
	}
	pl_event_cache_t *pec_get;
	pec_get = pl_return_cache_pointer(GET);
	if( pec_get!=NULL ) {
	    pl_event_cache_t *pec_put;
	    fd = pec_get->s.sockfd;
	    srv = pec_get->s.srv;
	    memset(pec_get, 0, sizeof(pl_event_cache_t));
	    pec_put = pl_return_cache_pointer(PUT);
	    if( pec_put==NULL ) {
		pl_assign_cache_pointer(PUT, pec_get);
	    }
	    pl_next_available_cache(GET);
	}
	alarm(remain);
    }
    if( srv==NULL ) {
	fd = socket(AF_INET, SOCK_STREAM, 0);
	pl_socket_t *other = pl_get_other_socket(acc);
	if( fd<0 ) {
	    pl_log(DEBUG, "pl_connect(): socket error. %s.", \
		strerror(errno));
	    close(acc->sockfd);
	    acc->status = other->status = DEAD;
	    pl_del_from_queue(pb);
	    return ;
	}
	pl_setnonblock(fd);
	pl_tcp_nodelay(fd);
	if( pl_chech_dynamic_lib(galname)<0 ) {
	    pl_log(DEBUG, "Switch to roundrobin.");
	    pl_set_algorithm("roundrobin");
	}
	srv = pl_call_algorithm(&ad);
	if( srv==NULL ) {
	    pl_log(DEBUG, "pl_connect(): no available server.");
	    close(acc->sockfd);
	    acc->status = other->status = DEAD;
	    pl_del_from_queue(pb);
	    return ;
	}
	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(srv->port);
	addr.sin_addr.s_addr = inet_addr(srv->ip);
	if( (rv = connect(fd, (struct sockaddr *)&addr, \
	     sizeof(addr)))<0 && errno==EINPROGRESS )
	{
	    status = INIT;
	} else if( rv<0 ) {
	    pl_log(DEBUG, "pl_connect(): connect error. %s.", \
		strerror(errno));
	    pl_stat_ctl(&(srv->info), FAILED, INC, 0);
	    close(acc->sockfd);
	    acc->status = other->status = DEAD;
	    pl_del_from_queue(pb);
	    return ;
	}
    }
    pl_stat_ctl(&(srv->info), IDLE, VALUE, 0);
    pl_socket_t *ps;
    ps = pl_get_other_socket(acc);
    ps->srv = srv;
    pl_set_socket(ps, CONNECT, NULL, pb, fd);
    ps->status = status;
    pl_stat_ctl(&clientinfo, CURRENT, INC, 0);
    pl_stat_ctl(&(srv->info), CURRENT, INC, 0);
    pl_add_sock_list(srv, ps);
    if( status==INIT ) {
	pl_ctl_event(ps, EPOLLOUT|EPOLLIN, ADD);
	pl_ctl_event(acc, EPOLLIN|EPOLLONESHOT|EPOLLET, ADD);
    } else {
	pl_ctl_event(ps, EPOLLIN|EPOLLONESHOT|EPOLLET, ADD);
	pl_ctl_event(acc, EPOLLIN|EPOLLONESHOT|EPOLLET, ADD);
    }
}

void pl_ctl_event(pl_socket_t *ps, pl_int_t flg, pl_int_t type)
{
    pl_int_t opt; pl_event_t ev;
    ev.data.ptr = ps; ev.events = flg;
    switch( type ) {
	case ADD:
	    nr_fds++; opt = EPOLL_CTL_ADD;
	    if( ps->status!=INIT ) ps->status = 0;
	    break;
	case MOD:
	    opt = EPOLL_CTL_MOD;
	    break;
	case DEL:
	    nr_fds--; opt = EPOLL_CTL_DEL;
	    break;
	default:
	    pl_log(EMERGE, \
	    "pl_ctl_event(): no such type code:%d.", type);
    }
    if( epoll_ctl(epfd, opt, ps->sockfd, &ev)<0 ) {
	pl_log(EMERGE, \
	"pl_ctl_event(): epoll_ctl error. %s.", strerror(errno));
    }
}

static void
pl_io(pl_socket_t *ps, pl_int_t flg)
{
    pl_int_t flag = 0;
    if( use_cache ) {
	flag = CACHE;
    }
    if( flg==RD ) {
	if( ps->type==(ACCEPT|LISTEN) || ps->type==CONNECT ) {
	    pl_request_recv(ps, flag);
	} else if( ps->type==(ACCEPT|CONSOLE) ) {
	    pl_console_recv(ps, "pl_console_recv()");
	} else if( ps->type==PAIR ) {
	    if( proc==MASTER ) {
		pl_master_ipc_recv(ps, "pl_master_ipc_recv()");
	    } else {
		pl_worker_ipc_recv(ps, "pl_worker_ipc_recv()");
	    }
	} else {
	    pl_log(EMERGE, "pl_io(): RD shouldn't be here.");
	}
    } else {
	if( ps->type==(ACCEPT|LISTEN) || ps->type==CONNECT ) {
	    pl_request_send(ps, flag);
	} else if( ps->type==(ACCEPT|CONSOLE) ) {	
	    pl_console_send(ps, "pl_console_send()");
	} else if( ps->type==PAIR ) {
	    if( proc==MASTER ) {
		pl_master_ipc_send(ps, "pl_master_ipc_send()");
	    } else {
		pl_worker_ipc_send(ps, "pl_worker_ipc_send()");
	    }
	} else {
	    pl_log(EMERGE, "pl_io(): WR shouldn't be here.");
	}
    }
}

