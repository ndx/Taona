
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
functions:
	pl_load_conf(), pl_nr_expression_check()
	pl_get_var() pl_get_local_domain()
attation:
	Before using this function, you need to make
	sure the parameter pointer is not NULL.
	pl_nr_expression(): to test the number of expre-
			    ssion's pieces.
	pl_get_var(): can get the D.I.Y variables' poin-
			ter. If not existed return NULL.
			This function can change the
			current domain pointer.
	pl_get_current_domain(): to get the current_domain.
	pl_check_layer(): check the variable's layer.
*/

#ifndef __PL_CONF
#define __PL_CONF
#include"pl_types.h"
#include"pl_str.h"
#include"pl_alloc.h"
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<ctype.h>
#include<unistd.h>

#define DOMAINNAME 256
#define VARNAME DOMAINNAME
#define LINELEN 1024
#define CACHELEN 16

#define INT 0x1
#define CHAR 0x2
#define STR 0x4

#define LIMITED -255
#define UNLIMITED -1

#define NONE 0
#define DOSW 0x1
#define SWIT 0x2
#define VAR 0x8000
#define DOM 0x10000

typedef struct pl_var_s {
	union {
		pl_int_t value;
		pl_char_t ch;
		pl_char_t *str;
	}data;
	pl_short_t type;
	pl_int_t layer;
	pl_uint_t unlimited:1;
	pl_uint_t depth:31;
	pl_char_t domain[DOMAINNAME];
	pl_char_t varname[VARNAME];
	struct pl_var_s *next;
}pl_var_t;

typedef struct pl_domain_s {
	pl_char_t domain[DOMAINNAME];
	pl_int_t layer;
	pl_var_t *pv;
	pl_var_t *pv_tail;
	struct pl_domain_s *next;
}pl_domain_t;

typedef struct pl_conf_s {
	pl_domain_t *pd;
	pl_pool_t *pool;
}pl_conf_t;

typedef struct pl_var_cache_s {
	pl_var_t *pv;
	pl_domain_t *pd;
	pl_uint_t actived:1;
	pl_uint_t nr_used:31;
}pl_var_cache_t;

void
pl_load_conf(const pl_char_t *path);
pl_int_t
pl_nr_expression_check(pl_char_t **part, \
			pl_int_t require);
void *
pl_get_conf(const pl_char_t *domain, \
		const pl_char_t *var, \
			pl_int_t flg);
pl_domain_t *
pl_get_current_domain(void);
void 
pl_check_nr_expression(pl_char_t **part, \
			pl_int_t require);
/*void pl_print(void);*/

#endif

