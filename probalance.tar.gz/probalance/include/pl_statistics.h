
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
functions:
	pl_stat_ctl() pl_get_stat_val()
	pl_init_stat_min_value()
Attention:
	These functions have two different macro sets.
*/

#ifndef __PL_STATISTICS
#define __PL_STATISTICS
#include"pl_types.h"

#define VALUE -4
#define NRVALUE 7
#define INC -2
#define NRINC 4
#define DEC -1
#define NRDEC 2
/*VALUE*/
#define IN 0
#define CWEIGHT 1
#define OUT 2
#define TIME 3
#define WEIGHT 4
#define DOWNSTATUS 5
#define IDLE 6
/*INC & DEC*/
#define CURRENT 0
#define NOTRANS 1
#define SUM 2
#define FAILED 3
/*definitions for pl_get_stat_value()*/
#define VIN 0
#define VOUT 1
#define VMAXIND 2
#define VMAXOUTD 3
#define VMINTIMEPC 4
#define VMAXTIMEPC 5
#define VALLTIME 6
#define VNOTRANS 7
#define VSUM 8
#define VCURRENT 9
#define VFAILED 10
#define VWEIGHT 11
#define VCWEIGHT 12
#define VDOWN 13
#define VIDLE 14
#define VNAME 15

#define STINAME 256

typedef struct pl_statinfo_s {
	pl_char_t name[STINAME];
	pl_ullong_t in;
	pl_ullong_t out;
	pl_ullong_t max_in_data;
	pl_ullong_t max_out_data;
	pl_ullong_t min_time_per_connection; /*usec*/
	pl_ullong_t max_time_per_connection; /*usec*/
	pl_ullong_t all_time; /*usec*/
	pl_ullong_t nr_notrans;
	pl_ullong_t sum_connections;
	pl_ullong_t current_connections;
	pl_ullong_t failed_connections;
	pl_int_t weight;
	pl_int_t current_weight;
	pl_int_t down;		/*restart flag for clientinfo*/
	pl_time_t idle;
}pl_statinfo_t;

typedef void (*pl_statis_t)\
	(pl_statinfo_t *pst, \
	pl_ullong_t val);

typedef void (*pl_statdata_t)\
	(pl_statinfo_t *pst, \
	void *val, pl_int_t size);

void pl_stat_ctl(pl_statinfo_t *pst, \
			pl_int_t item, \
			pl_int_t type, \
			pl_ullong_t val);
void pl_get_stat_value(pl_statinfo_t *pst, \
			pl_int_t var, \
			void *val, \
			pl_int_t size);
void pl_init_stat_min_value(pl_statinfo_t *pst);
#endif

