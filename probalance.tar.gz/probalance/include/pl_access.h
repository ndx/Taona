
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
functions:
	pl_init_access() pl_ip_atoi()
	pl_ctl_acl_rule() pl_test_acl()
	pl_get_acl_status() pl_get_nr_acl()
	pl_get_acllist() pl_clean_all_acl()
	pl_change_acl_status()
attention:
	pl_ip_atoi(): on error, IPERR is returned.
	pl_ctl_acl_rule(): if type is DELACL, then the
	return pointer is not recommended to be used.
*/

#ifndef __PL_ACCESS
#define __PL_ACCESS

#include"pl_types.h"
#include"pl_alloc.h"
#define BUF 1024
#define PATH 256
#define DENY 0x800000
#define ALLOW 0x400000
#define IPERR ~0

#ifdef __PL_RULE
#define ADDACL 0x1
#define MODACL 0x2
#define DELACL 0x3
#define SELACL 0x4
#endif

typedef struct pl_rule_s {
	pl_int_t num;
	pl_int_t nr_ip;
	pl_uint_t ip;
	pl_int_t rule;
	struct pl_rule_s *next;
	struct pl_rule_s *prev;
}pl_rule_t;

typedef struct pl_access_s {
	pl_rule_t *pr;
	pl_rule_t *pr_tail;
	pl_pool_t *pool;
	pl_int_t status;
}pl_access_t;

void pl_init_access(void);
pl_uint_t pl_ip_atoi(pl_char_t *ip);
pl_rule_t *pl_ctl_acl_rule(pl_int_t num, \
	pl_char_t *ip, pl_int_t netbit, \
	pl_char_t *rule, pl_int_t type);
pl_int_t pl_test_acl(pl_char_t *ip);
pl_int_t pl_get_acl_status(void);
pl_int_t pl_get_nr_acl(void);
pl_rule_t *pl_get_acllist(void);
void pl_get_acl_conf(const pl_char_t *path);
void pl_clean_all_acl(void);
void pl_change_acl_status(pl_int_t status);
/*void pl_print_acl(void);*/
#endif

