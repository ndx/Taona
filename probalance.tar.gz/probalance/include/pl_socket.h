
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
functions:
	    pl_init_socket()
	    pl_init_cache_stuff() pl_clean_all_cache()
	    pl_assign_cache_pointer()
	    pl_return_cache_pointer()
	    pl_next_available_cache()
	    pl_get_connection_cache_status()
	    pl_clean_cache_by_server()
	    pl_create_bind() pl_add_in_queue()
	    pl_del_from_queue() pl_get_bind()
	    pl_clean_socket_memory()
	    pl_create_socket() pl_set_socket()
	    pl_del_socket() pl_get_other_socket()
	    pl_create_chain_node() pl_add_chain_node()
	    pl_del_chain_node() pl_delall_chain_node()
	    pl_xchg_chain_node()
	    pl_setnonblock() pl_setreuseaddr()
	    pl_tcp_nodelay()
	    pl_add_sock_list() pl_del_sock_list()
	    pl_del_all_sock_list()
*/

#ifndef __PL_SOCKET
#define __PL_SOCKET

#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include"pl_types.h"
#include"pl_socket_types.h"
#include"pl_alloc.h"
#include"pl_server.h"
/*type*/
#define CONNECT 0x10
#define ACCEPT 0x01
#define PAIR 0x02
#define CONSOLE 0x04
#define LISTEN 0x08
#define MOV 4
#define COMMON 0
/*status*/
#define SUSPEND 0x8000
#define SENDING 0x4000
#define DEAD 0x2000
#define INIT 0x1000
#define ALLDEAD 0x20002000
/*common*/
#define IPLEN 32
#define BUFLEN 1024
#define BACKLOG 511
#define CACHESIZE 128
#define GET 0xffff
#define PUT 0x10000
#define HBSEC 30
#define BROKENSEC 180

struct pl_chain_s {
	void *buf;
	pl_int_t size;
	pl_int_t w_size;
	struct pl_chain_s *next;
};

typedef struct pl_sock_list_s {
	pl_socket_t *ps;
	struct pl_sock_list_s *next;
	struct pl_sock_list_s *prev;
}pl_sock_list_t;

struct pl_socket_s {
	pl_int_t sockfd;
	pl_int_t type;
	pl_int_t nr_buf;
	pl_int_t packlen;	/*for ipc*/
	pl_int_t nr_answer;	/*for ipc*/
	pl_uint_t status;
	pl_ullong_t in;
	pl_ullong_t out;
	pl_chain_t *pc;
	pl_chain_t *pc_tail;
	pl_bind_t *pb;
	pl_server_t *srv;
	pl_sock_list_t *psl;
	struct sockaddr_in addr;
	struct timeval start;
};

struct pl_bind_s {
	pl_socket_t s[2];
	pl_uint_t status;
	struct pl_bind_s *next;
	struct pl_bind_s *prev;
};

struct pl_queue_s {
	pl_bind_t *pb;
	pl_bind_t *pb_tail;
	pl_bind_t *rm;
	pl_bind_t *rm_tail;
	pl_int_t cache_status;
	pl_pool_t *pool;
};

typedef struct pl_event_cache_s {
	pl_socket_t s;
	pl_time_t start;
}pl_event_cache_t;

/*declarations*/
void pl_init_socket(void);
/*options*/
void pl_setnonblock(pl_int_t fd);
void pl_setreuseaddr(pl_int_t fd);
void pl_tcp_nodelay(pl_int_t fd);
/*cache*/
void pl_init_cache_stuff(void);
void pl_clean_all_cache(void);
pl_event_cache_t *pl_return_cache_pointer(pl_int_t flg);
void pl_assign_cache_pointer(pl_int_t flg, \
			pl_event_cache_t *pec);
void pl_next_available_cache(pl_int_t flg);
pl_int_t pl_get_connection_cache_status(void);
void pl_clean_cache_by_server(pl_server_t *srv);
/*bind*/
pl_bind_t *pl_create_bind(void);
void pl_add_in_queue(pl_bind_t *pb);
void pl_del_from_queue(pl_bind_t *pb);
pl_bind_t *pl_get_bind(void);
void pl_clean_socket_memory(void);
/*socket*/
pl_socket_t *pl_create_socket(void);
void pl_set_socket(pl_socket_t *ps, \
			pl_int_t type, \
			struct sockaddr_in *addr, \
			pl_bind_t *pb, \
			pl_int_t sockfd);
void pl_del_socket(pl_socket_t *ps);
pl_socket_t *pl_get_other_socket(pl_socket_t *ps);
void pl_xchg_chain_node(pl_socket_t *src, \
			pl_socket_t *dest);
/*chain*/
pl_chain_t *pl_create_chain_node(void);
void pl_del_chain_node(pl_socket_t *ps, \
			pl_chain_t *pc);
void pl_add_chain_node(void *buf, \
			pl_int_t size, \
			pl_socket_t *ps, \
			pl_chain_t *pc);
void pl_delall_chain_node(pl_socket_t *ps);
/*sock_list*/
void pl_add_sock_list(pl_server_t *srv,\
			pl_socket_t *ps);
void pl_del_sock_list(pl_server_t *srv, \
			pl_socket_t *ps);
void pl_del_all_sock_list(pl_server_t *srv);
/*void pl_print_sock(void);*/
#endif

