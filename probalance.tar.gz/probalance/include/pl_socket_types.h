
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_SOCKTYPE
#define __PL_SOCKTYPE

#include"pl_socket.h"
typedef struct pl_chain_s pl_chain_t;
typedef struct pl_socket_s pl_socket_t;
typedef struct pl_bind_s pl_bind_t;
typedef struct pl_queue_s pl_queue_t;

#endif

