
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_TYPES
#define __PL_TYPES

#include<sys/types.h>

typedef char pl_char_t;
typedef unsigned char pl_uchar_t;
typedef int pl_int_t;
typedef unsigned int pl_uint_t;
typedef long pl_long_t;
typedef unsigned long pl_ulong_t;
typedef long long pl_llong_t;
typedef unsigned long long pl_ullong_t;
typedef short pl_short_t;
typedef unsigned short pl_ushort_t;
typedef time_t pl_time_t;
typedef pid_t pl_pid_t;

#endif

