
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_EVENT
#define __PL_EVENT

#include"pl_types.h"
#include"pl_alloc.h"
#include"pl_socket.h"
#include<sys/epoll.h>

#define EVENTSIZE 512
#define ADD 0x1
#define MOD 0x2
#define DEL 0x4
#define RD 0x10
#define WR 0x20
#define CACHE 0x8000
#define OVERLOAD 4096

typedef struct epoll_event pl_event_t;

pl_int_t pl_event(pl_char_t *argv[]);
void pl_ctl_event(pl_socket_t *ps, \
	pl_int_t flg, pl_int_t type);
#endif

