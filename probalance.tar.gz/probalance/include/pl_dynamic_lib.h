
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_DYNAMIC_LIB
#define __PL_DYNAMIC_LIB
#include"pl_types.h"

pl_int_t pl_init_dynamic_lib(void);
pl_int_t
pl_chech_dynamic_lib(const pl_char_t *algname);
void *pl_return_alptr(const pl_char_t *alname);
void pl_close_lib(void);
#endif

