
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
functions:
	pl_slice pl_slicev pl_end_slice
attention:
	After using the return pointer of pl_slice(),
	you need to call pl_end_slice() to free the
	storage space of the pointer.
*/

#ifndef __PL_STR
#define __PL_STR

#include"pl_types.h"
#include"stdarg.h"

pl_char_t **pl_slice(pl_char_t *str, \
			pl_int_t nr_arg, \
			.../*, (char *)0*/);
pl_char_t **pl_slicev(pl_char_t *str, \
			pl_int_t nr_arg, \
			va_list arg);
void pl_end_slice(pl_char_t **ptr);
#endif

